define("CopyFBox08c606abedf334f", function() {
    return function(controller) {
        CopyFBox08c606abedf334f = new kony.ui.FlexContainer({
            "clipBounds": true,
            "height": "40dp",
            "id": "CopyFBox08c606abedf334f",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "width": "100%"
        }, {}, {});
        CopyFBox08c606abedf334f.setDefaultUnit(kony.flex.DP);
        var lblResName = new kony.ui.Label({
            "centerY": "50%",
            "id": "lblResName",
            "isVisible": true,
            "left": "0dp",
            "skin": "slLabel",
            "text": "Label",
            "width": kony.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, {
            "containerWeight": 100,
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "hExpand": true,
            "margin": [1, 1, 1, 1],
            "marginInPixel": false,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false,
            "vExpand": false,
            "widgetAlignment": constants.WIDGET_ALIGN_CENTER
        }, {
            "textCopyable": false,
            "wrapping": constants.WIDGET_TEXT_WORD_WRAP
        });
        CopyFBox08c606abedf334f.add(lblResName);
        return CopyFBox08c606abedf334f;
    }
})