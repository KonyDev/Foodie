var RESTAURANT_CONFIG = {
    "USER_KEY": "de7c3b6703285fcd9c6d2e6c61eca6ee",
    "LATITUDE": "",
    "LONGITUDE": ""
};
var KMSPROP = {
    senderID: "947073648918"
};
var provider = {
    "googleProvider": "GoogleOauth",
    "facebookProvider": "FacebookLogin"
};
/**
 * Name		:	offlinePushNotificationAndroidCallback
 * Author	:	Kony
 * Purpose	:	This function is the callback for the received push msg event while offline
 **/
function offlinePushNotificationAndroidCallback(msg) {
    kony.print("************ JS offlinePushNotificationCallback() called *********");
    kony.print(msg);
    if (msg["content-available"] != 1) {
        alert("Message: " + msg["content"]);
    } else {
        kony.print("silent push received");
    }
}
/**
 * Name		:	onlinePushNotificationAndroidCallback
 * Author	:	Kony
 * Purpose	:	This function is the callback for the received push msg event while online.
 **/
function onlinePushNotificationAndroidCallback(msg) {
    kony.print("************ JS onlinePushNotificationCallback() called *********");
    kony.print(JSON.stringify(msg));
    if (msg["content-available"] != 1) {
        if (msg["isRichPush"] !== undefined) {
            kony.print("rich push message received");
            //displayRichPush(msg);
        } else alert("Message: " + msg["content"]);
    } else {
        alert("Silent Push Received");
    }
}
/**
 * Name		:	regFailureAndroidCallback
 * Author	:	Kony
 * Purpose	:	This function is the callback for the registration failure to the GCM server.
 **/
function regFailureAndroidCallback(errormsg) {
    kony.print("Registration Failed:" + JSON.stringify(errormsg));
    kony.application.dismissLoadingScreen();
    alert("Registration Failed ");
}
/**
 * Name		:	regSuccessAndroidCallback
 * Author	:	Kony
 * Purpose	:	This function is the callback for the successful registration of the device to the GCM server & returns the callerID.
 * 
 **/
function regSuccessAndroidCallback(regId) {
    kony.print("\n\n\n<--------in regSuccessAndroidCallback--------->\n\n\n");
    kony.print("\nRegistration Id-->" + JSON.stringify(regId));
    subscribeForPushNotification(regId);
    //registrationID=regId;
    //kony.store.setItem("isFirstTime","true");
    //pushSubscription(regId,"android");
}
/**
 * Name		:	callbackAndroidSetCallbacks
 * Author	:	Kony
 * Purpose	:	This function sets the callback for registration,deregistration & pushnotification events.
 **/
function callbackAndroidSetCallbacks() {
    kony.print("\n\n\n<--------in callbackAndroidSetCallbacks--------->\n\n\n");
    kony.push.setCallbacks({
        onsuccessfulregistration: regSuccessAndroidCallback,
        onfailureregistration: regFailureAndroidCallback,
        onlinenotification: onlinePushNotificationAndroidCallback,
        offlinenotification: offlinePushNotificationAndroidCallback,
        onsuccessfulderegistration: unregSuccessAndroidCallback,
        onfailurederegistration: unregFailureAndroidCallback
    });
}

function unregSuccessAndroidCallback() {
    kony.print("unregSuccess");
}

function unregFailureAndroidCallback() {
    kony.print("unregFailure");
}