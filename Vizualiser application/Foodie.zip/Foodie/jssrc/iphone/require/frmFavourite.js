define("frmFavourite", function() {
    return function(controller) {
        function addWidgetsfrmFavourite() {
            this.setDefaultUnit(kony.flex.DP);
            var flxTitle = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "9%",
                "id": "flxTitle",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 2
            }, {}, {});
            flxTitle.setDefaultUnit(kony.flex.DP);
            var lblztitle = new kony.ui.Label({
                "centerX": "50%",
                "centerY": "50%",
                "id": "lblztitle",
                "isVisible": true,
                "skin": "sknLblTitle2",
                "text": "Favourite",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "textCopyable": false,
                "wrapping": constants.WIDGET_TEXT_WORD_WRAP
            });
            var btnHome = new kony.ui.Button({
                "centerY": "50%",
                "focusSkin": "sknBtnTrans",
                "height": "100%",
                "id": "btnHome",
                "isVisible": true,
                "onClick": controller.AS_Button_f1f1410203244258a33f3c2e49cd4d11,
                "right": "10dp",
                "skin": "sknBtnTrans",
                "text": "Home",
                "top": "1dp",
                "width": "70dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "showProgressIndicator": true
            });
            flxTitle.add(lblztitle, btnHome);
            var flxRootContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "91%",
                "id": "flxRootContainer",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "skin": "slFbox",
                "top": "9%",
                "width": "100%",
                "zIndex": 1
            }, {}, {});
            flxRootContainer.setDefaultUnit(kony.flex.DP);
            var segRestaurant = new kony.ui.SegmentedUI2({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "data": [{
                    "imgDelete": "deletee.png",
                    "imgResIcon": "imagedrag.png",
                    "lblCuisines": "Cuisines",
                    "lblLine": "",
                    "lblRating": "4.5",
                    "lblResName": "Restaurant name"
                }, {
                    "imgDelete": "deletee.png",
                    "imgResIcon": "imagedrag.png",
                    "lblCuisines": "Cuisines",
                    "lblLine": "",
                    "lblRating": "4.5",
                    "lblResName": "Restaurant name"
                }, {
                    "imgDelete": "deletee.png",
                    "imgResIcon": "imagedrag.png",
                    "lblCuisines": "Cuisines",
                    "lblLine": "",
                    "lblRating": "4.5",
                    "lblResName": "Restaurant name"
                }],
                "groupCells": false,
                "height": "100%",
                "id": "segRestaurant",
                "isVisible": true,
                "left": "0dp",
                "needPageIndicator": true,
                "onRowClick": controller.AS_Segment_a6ad63bb0a4844e0982c8d98b1fcc8d6,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowFocusSkin": "Copyseg0ad33c17cd47345",
                "rowSkin": "Copyseg0ad33c17cd47345",
                "rowTemplate": "flxFavRootContainer",
                "scrollingEvents": {},
                "sectionHeaderSkin": "sliPhoneSegmentHeader",
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorRequired": true,
                "showScrollbars": false,
                "top": "0dp",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {
                    "flxDelete": "flxDelete",
                    "flxDeleteRestaurant": "flxDeleteRestaurant",
                    "flxFavRootContainer": "flxFavRootContainer",
                    "flxRestaurantInfo": "flxRestaurantInfo",
                    "flxTitle": "flxTitle",
                    "imgDelete": "imgDelete",
                    "imgResIcon": "imgResIcon",
                    "lblCuisines": "lblCuisines",
                    "lblLine": "lblLine",
                    "lblRating": "lblRating",
                    "lblResName": "lblResName"
                },
                "width": "100%",
                "zIndex": 1
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "bounces": true,
                "editStyle": constants.SEGUI_EDITING_STYLE_NONE,
                "enableDictionary": false,
                "indicator": constants.SEGUI_ROW_SELECT,
                "progressIndicatorColor": constants.PROGRESS_INDICATOR_COLOR_WHITE,
                "showProgressIndicator": true
            });
            flxRootContainer.add(segRestaurant);
            this.add(flxTitle, flxRootContainer);
        };
        return [{
            "addWidgets": addWidgetsfrmFavourite,
            "enabledForIdleTimeout": false,
            "id": "frmFavourite",
            "layoutType": kony.flex.FREE_FORM,
            "needAppMenu": false,
            "skin": "sknFrmGrey",
            "info": {
                "kuid": "3b98cb91816447a899c7cd3b761440d2"
            }
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": kony.flex.FREE_FORM,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {
            "configureExtendBottom": false,
            "configureExtendTop": false,
            "configureStatusBarStyle": false,
            "footerOverlap": false,
            "formTransparencyDuringPostShow": "100",
            "headerOverlap": false,
            "inputAccessoryViewType": constants.FORM_INPUTACCESSORYVIEW_CANCEL,
            "needsIndicatorDuringPostShow": false,
            "retainScrollPosition": false,
            "titleBar": false,
            "titleBarSkin": "slTitleBar"
        }]
    }
});