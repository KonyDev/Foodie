define({
    "restaurantList": [],
    "abc": {
        "mykey": "myvalue"
    },
    "def": "hello",
    "onNavigate": function(param) {
        if (param === undefined || param === null) return;
        this.view.imgLogo.src = param;
        this.setGestureRecognizer();
        //alert("param");
    },
    "signOut": function() {
        // Sample code to logout from auth service
        try {
            var navigateObject = new kony.mvc.Navigation("frmBrowser");
            var data = {
                "provider": "GoogleOauth",
                "operation": "logOut"
            };
            navigateObject.navigate(data);
        } catch (exp) {
            kony.print(JSON.stringify(exp));
        }
    },
    "callbackAndroidRegister": function() {
        if (KMSPROP.senderID === "" || KMSPROP.senderID === null || KMSPROP.senderID === undefined) {
            alert("sender id is missing");
            kony.print("sender id is missing");
            return;
        }
        kony.print("senid:" + KMSPROP.senderID)
        var configToRegister = {
            senderid: KMSPROP.senderID
        };
        kony.push.register(configToRegister);
    },
    "pushRegistration": function() {
        kony.print("\n\n----in pushRegister----\n");
        var devName = kony.os.deviceInfo().name;
        //kony.application.showLoadingScreen("sknLoading", "please wait..", constants.LOADING_SCREEN_POSITION_FULL_SCREEN, true, true, null);
        if (devName === "android") {
            //callbackAndroidSetCallbacks();
            this.callbackAndroidRegister();
        } else if ((devName == "iPhone") || (devName == "iPhone Simulator") || (devName == "iPad") || (devName == "iPad Simulator")) {
            alert("WIP");
            // callbackiPhoneSetCallbacks();
            //callbackiPhoneRegister();
        }
    },
    "navigateToFormProfile": function() {
        try {
            var navigateObject = new kony.mvc.Navigation("frmProfile");
            navigateObject.navigate();
        } catch (exp) {
            kony.print(JSON.stringify(exp));
        }
    },
    "dummyFun": function() {
        kony.print("dummey function");
    },
    "formInit": function() {
        alert("form init called");
        kony.print("form init called");
    },
    "leftAnimObj": function() {
        var animConf = {
            100: {
                "left": "-100%",
                "stepConfig": {
                    "timingFunction": kony.anim.LINEAR
                }
            }
        };
        var animObj = kony.ui.createAnimation(animConf);
        return animObj;
    },
    "rightAnimObj": function() {
        var animConf = {
            "100": {
                "left": "0%",
                "stepConfig": {
                    "timingFunction": kony.anim.LINEAR
                }
            }
        };
        var animObj = kony.ui.createAnimation(animConf);
        return animObj;
    },
    "setGestureRecognizer": function() {
        var controllerScope = this;

        function swipeGestureHandler(commonWidget, gestureInfo, context) {
            kony.print("\n swipe performed\n");
            try {
                var direction = "";
                var GesType = "" + gestureInfo.gestureType;
                var animObj;
                if (GesType == constants.GESTURE_TYPE_SWIPE) {
                    var swipeDirection = "" + gestureInfo.swipeDirection; //Read swipe direction
                    // alert(swipeDirection);
                    if (swipeDirection == "1") {
                        controllerScope.view.flxMenuContainer.animate(kony.ui.createAnimation({
                            100: {
                                left: "-100%",
                                "stepConfig": {}
                            }
                        }), {
                            delay: 0,
                            fillMode: kony.anim.FILL_MODE_FORWARDS,
                            duration: .40
                        }, {
                            animationEnd: function() {}
                        });
                    } else if (swipeDirection == "2") {
                        controllerScope.view.flxMenuContainer.animate(kony.ui.createAnimation({
                            100: {
                                left: "0%",
                                "stepConfig": {}
                            }
                        }), {
                            delay: 0,
                            fillMode: kony.anim.FILL_MODE_FORWARDS,
                            duration: .40
                        }, {
                            animationEnd: function() {}
                        });
                    }
                }
            } catch (exp) {
                alert("error while performing animation" + JSON.stringify(exp));
            }
        }
        try {
            kony.print("$$$$$$$$$$$$$ in setGestureRecognizer $$$$$$$");
            this.view.addGestureRecognizer(constants.GESTURE_TYPE_SWIPE, {
                fingers: 1,
                swipedistance: 50,
                swipevelocity: 75
            }, swipeGestureHandler);
        } catch (err) {
            alert("error while regestering the gestures:" + err);
        }
    },
    "showMenu": function() {
        this.view.flxMenuContainer.animate(kony.ui.createAnimation({
            100: {
                left: "0%",
                "stepConfig": {}
            }
        }), {
            delay: 0,
            fillMode: kony.anim.FILL_MODE_FORWARDS,
            duration: .40
        }, {
            animationEnd: function() {}
        });
    },
    "onMyRowClick": function() {
        var selectedRowIndex = this.view.segRestaurant.selectedRowIndex[1];
        try {
            var navigateTofrmDetails = new kony.mvc.Navigation("frmResDetails");
            var resObj = this.restaurantList[selectedRowIndex];
            navigateTofrmDetails.navigate(resObj);
        } catch (exp) {
            kony.print(JSON.stringify(exp));
        }
    },
    "onFetchData": function(sc, ec) {
        var myController = this;

        function success(data) {
            kony.print("in sc of frmRestaurant controller:" + JSON.stringify(data));
            myController.restaurantList = data._raw_response_.segRestaurant.records;
            // alert(this.def);
            // alert(JSON.stringify(this.restaurantList));
            sc(data);
        }

        function error(err) {
            kony.print("in error of frmRestaurant controller:" + JSON.stringify(err));
            ec(err);
        }
        kony.model.ApplicationContext.showLoadingScreen("Loading restaurants ...");
        this.fetchData(success.bind(this), error);
    },
    "navigateTofrmFavourite": function() {
        try {
            var navigateToFavourite = new kony.mvc.Navigation("frmFavourite");
            navigateToFavourite.navigate(this.restaurantObj);
        } catch (exp) {
            kony.print(JSON.stringify(exp));
        }
    },
    "getFavouriteRestaurant": function() {
        var params = {};
        params.queryParams = {
            device_id: kony.os.deviceInfo().id,
            // device_id: undefined
        };
        var navigateTofrmFavourite = new kony.mvc.Navigation("frmFavourite");
        var modelContext = new kony.model.ModelContext();
        modelContext.setRequestOptions("segRestaurant", params);
        navigateTofrmFavourite.setFormConfig(frmFavouriteConfig);
        navigateTofrmFavourite.setModelContext(modelContext);
        try {
            navigateTofrmFavourite.navigate();
        } catch (exp) {
            kony.print("Error in navigating the form");
        }
    },
    "AS_Image_f6fd8ab84b3345dba6185ea77fe209b8": function AS_Image_f6fd8ab84b3345dba6185ea77fe209b8(eventobject, x, y) {
        var self = this;
        this.showMenu();
    },
    "AS_Segment_5df59f9c2d334da3a72011f5ffb8520b": function AS_Segment_5df59f9c2d334da3a72011f5ffb8520b(eventobject, sectionNumber, rowNumber) {
        var self = this;
        this.onMyRowClick();
    },
    "AS_Button_f2b727fb77084e958bffbd1ea029e41f": function AS_Button_f2b727fb77084e958bffbd1ea029e41f(eventobject) {
        var self = this;
        this.navigateToFormProfile();
    },
    "AS_Button_80d8337ad975457784c8d6fd7a336e5d": function AS_Button_80d8337ad975457784c8d6fd7a336e5d(eventobject) {
        var self = this;
        this.getFavouriteRestaurant();
    },
    "AS_Button_3817c3dc2db44de8b512d1f9937df796": function AS_Button_3817c3dc2db44de8b512d1f9937df796(eventobject) {
        var self = this;
        this.pushRegistration();
    },
    "AS_Button_ab26757515d34db2a60f5ef2ffe46323": function AS_Button_ab26757515d34db2a60f5ef2ffe46323(eventobject) {
        var self = this;
        this.signOut();
    },
    "AS_FlexContainer_7127bf2110594b479dd57e62f7142247": function AS_FlexContainer_7127bf2110594b479dd57e62f7142247(eventobject) {
        var self = this;
        this.dummyFun();
    },
    "AS_Form_553c8effd5dd4e03b7bdf75b9c55a878": function AS_Form_553c8effd5dd4e03b7bdf75b9c55a878(eventobject) {
        var self = this;
        //this.setGestureRecognizer();
    }
})