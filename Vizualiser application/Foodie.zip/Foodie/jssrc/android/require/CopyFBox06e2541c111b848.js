define("CopyFBox06e2541c111b848", function() {
    return function(controller) {
        CopyFBox06e2541c111b848 = new kony.ui.FlexContainer({
            "clipBounds": true,
            "height": "40dp",
            "id": "CopyFBox06e2541c111b848",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "width": "100%"
        }, {}, {});
        CopyFBox06e2541c111b848.setDefaultUnit(kony.flex.DP);
        var lblResName = new kony.ui.Label({
            "centerY": "50%",
            "id": "lblResName",
            "isVisible": true,
            "left": "0dp",
            "skin": "slLabel",
            "text": "Label",
            "textStyle": {
                "letterSpacing": 0,
                "strikeThrough": false
            },
            "width": kony.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, {
            "containerWeight": 100,
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "hExpand": true,
            "margin": [1, 1, 1, 1],
            "marginInPixel": false,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false,
            "vExpand": false,
            "widgetAlignment": constants.WIDGET_ALIGN_CENTER
        }, {
            "textCopyable": false
        });
        CopyFBox06e2541c111b848.add(lblResName);
        return CopyFBox06e2541c111b848;
    }
})