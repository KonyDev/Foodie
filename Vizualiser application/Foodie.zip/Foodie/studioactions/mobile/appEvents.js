define({
    AS_AppEvents_j3fdee38f72542aaaf876abfc82dc2e8: function AS_AppEvents_j3fdee38f72542aaaf876abfc82dc2e8(eventobject) {
        var self = this;
        return setCallBacks.call(this);
    }
});