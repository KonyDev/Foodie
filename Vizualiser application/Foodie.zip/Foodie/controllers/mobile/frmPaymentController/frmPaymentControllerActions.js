define({
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    AS_Button_ga709817d4fd4e349048942f3d6e8370: function AS_Button_ga709817d4fd4e349048942f3d6e8370(eventobject) {
        var self = this;
        this.navigateTofrmHome();
    }
});