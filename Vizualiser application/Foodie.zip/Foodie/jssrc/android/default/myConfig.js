var RESTAURANT_CONFIG = {
    "USER_KEY": "de7c3b6703285fcd9c6d2e6c61eca6ee",
    "LATITUDE": "",
    "LONGITUDE": "",
    "GOOGLE_PROVIDER": "ZGoogleOAuthv2"
};
var KMSPROP = {
    senderID: "947073648918"
};
var PROVIDER = {
    "googleProvider": "ZGoogleOAuthv2",
    "facebookProvider": "FacebookLogin"
};