define({
    "onNavigate": function(restaurantObj) {
        var menu_url = restaurantObj["menu_url"];
        this.view.browser.requestURLConfig = {
            "URL": menu_url
        };
    }
})