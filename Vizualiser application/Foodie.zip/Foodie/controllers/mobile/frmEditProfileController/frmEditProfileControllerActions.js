define({
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    AS_Button_6059884174c64c95a2df0c2d1492e4ca: function AS_Button_6059884174c64c95a2df0c2d1492e4ca(eventobject) {
        var self = this;
        this.navigateToFormHome();
    },
    AS_Button_ca5df96be4ce4ca0a45a350f09e789d3: function AS_Button_ca5df96be4ce4ca0a45a350f09e789d3(eventobject) {
        var self = this;
        this.updateDetails();
    }
});