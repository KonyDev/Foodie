define({
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    AS_Button_e9bb141705214ebfae8d61380c33c2b1: function AS_Button_e9bb141705214ebfae8d61380c33c2b1(eventobject) {
        var self = this;
        this.getFavouriteRestaurant();
    },
    AS_Button_1f93c31c271f4b1f8abb09ea642814aa: function AS_Button_1f93c31c271f4b1f8abb09ea642814aa(eventobject) {
        var self = this;
        this.navigateTofrmHome();
    }
});