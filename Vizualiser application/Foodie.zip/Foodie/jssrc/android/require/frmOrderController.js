define({
    "navigateTofrmHome": function() {
        try {
            var navigateObj = new kony.mvc.Navigation("frmHome");
            navigateObj.navigate();
        } catch (exp) {
            kony.print(JSON.stringify(exp));
        }
    },
    "onNavigate": function(restaurantObj) {
        if (restaurantObj === null || restaurantObj === undefined) return;
        this.resObj = restaurantObj;
        var order_url = restaurantObj["order_url"];
        this.view.browser.requestURLConfig = {
            "URL": order_url
        };
    },
    "makePayment": function() {
        try {
            var navigateObj = new kony.mvc.Navigation("frmPayment");
            navigateObj.navigate();
        } catch (exp) {
            kony.print(JSON.stringify(exp));
        }
    },
    "AS_Button_bc66672300d246df813757cfb5a121c1": function AS_Button_bc66672300d246df813757cfb5a121c1(eventobject) {
        var self = this;
        this.navigateTofrmHome();
    },
    "AS_Button_f61b6da550754cb3864e11c8a729c9c3": function AS_Button_f61b6da550754cb3864e11c8a729c9c3(eventobject) {
        var self = this;
        this.makePayment();
    }
})