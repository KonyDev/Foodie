define({
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    AS_FlexContainer_2661e555919d430cb950404c7f89eca6: function AS_FlexContainer_2661e555919d430cb950404c7f89eca6(eventobject) {
        var self = this;
        this.testMethod();
    }
});