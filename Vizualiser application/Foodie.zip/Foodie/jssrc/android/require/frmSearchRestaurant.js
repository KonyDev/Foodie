define("frmSearchRestaurant", function() {
    return function(controller) {
        function addWidgetsfrmSearchRestaurant() {
            this.setDefaultUnit(kony.flex.DP);
            var flxRoot = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxRoot",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {}, {});
            flxRoot.setDefaultUnit(kony.flex.DP);
            var flxTitle = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "9%",
                "id": "flxTitle",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "skin": "sknFlxTitle",
                "top": "0dp",
                "width": "100%",
                "zIndex": 2
            }, {}, {});
            flxTitle.setDefaultUnit(kony.flex.DP);
            var lblTitle = new kony.ui.Label({
                "centerX": "50%",
                "centerY": "50%",
                "id": "lblTitle",
                "isVisible": true,
                "skin": "sknLblTitle2",
                "text": "Home",
                "textStyle": {
                    "letterSpacing": 0,
                    "strikeThrough": false
                },
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "textCopyable": false
            });
            var btnFavourite = new kony.ui.Button({
                "centerY": "50%",
                "focusSkin": "sknBtnFavourite",
                "height": "30dp",
                "id": "btnFavourite",
                "isVisible": true,
                "onClick": controller.AS_Button_a93614de9cbc4844909c2c7033b4404b,
                "right": "10dp",
                "skin": "sknBtnFavourite",
                "width": "80dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnHome = new kony.ui.Button({
                "centerY": "50%",
                "focusSkin": "sknBtnHome",
                "height": "35dp",
                "id": "btnHome",
                "isVisible": true,
                "left": "10dp",
                "onClick": controller.AS_Button_i7591569f6ce40c4a718993123479ab8,
                "skin": "sknBtnHome",
                "width": "35dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxTitle.add(lblTitle, btnFavourite, btnHome);
            var flxContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "91%",
                "id": "flxContainer",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "skin": "sknFlxDarkGrey2",
                "top": "9%",
                "width": "100%",
                "zIndex": 2
            }, {}, {});
            flxContainer.setDefaultUnit(kony.flex.DP);
            var flxCity = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "height": "60dp",
                "id": "flxCity",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "skin": "CopyslFbox0f4cc2a83a04842",
                "top": "10dp",
                "width": "95%",
                "zIndex": 100
            }, {}, {});
            flxCity.setDefaultUnit(kony.flex.DP);
            var txtBoxCity = new kony.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "centerY": "50%",
                "height": "40dp",
                "id": "txtBoxCity",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "1%",
                "placeholder": "search city",
                "secureTextEntry": false,
                "skin": "CopyslTextBox0ede41e7ee6dc45",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "90dp",
                "width": "290dp",
                "zIndex": 1
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoFilter": false,
                "keyboardActionLabel": constants.TEXTBOX_KEYBOARD_LABEL_DEFAULT,
                "placeholderSkin": "CopyslTextBox0ec4793f83e1548",
                "viewType": constants.TEXTBOX_VIEW_TYPE_DEFAULT
            });
            var btnSearchCity = new kony.ui.Button({
                "centerY": "50%",
                "focusSkin": "sknBtnSearch",
                "height": "50dp",
                "id": "btnSearchCity",
                "isVisible": true,
                "left": "0dp",
                "onClick": controller.AS_Button_e9d060fb41cf4ef5b9a3a90fe0f9d414,
                "skin": "sknBtnSearch",
                "top": "87dp",
                "width": "50dp",
                "zIndex": 50
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxCity.add(txtBoxCity, btnSearchCity);
            var flxCuisines = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "height": "55dp",
                "id": "flxCuisines",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "skin": "CopyslFbox0hf270c2dc92943",
                "top": "0dp",
                "width": "95%",
                "zIndex": 10
            }, {}, {});
            flxCuisines.setDefaultUnit(kony.flex.DP);
            var lstBoxCuisines = new kony.ui.ListBox({
                "centerY": "50%",
                "height": "40dp",
                "id": "lstBoxCuisines",
                "isVisible": true,
                "left": "2%",
                "masterData": [
                    ["-1", "select cuisines"]
                ],
                "onSelection": controller.AS_ListBox_fdcc9057f78142ee947e602934d655d4,
                "skin": "CopyslListBox0if10cb6cb68041",
                "top": "10dp",
                "width": "85%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "applySkinsToPopup": true,
                "placeholder": "select cuisines..",
                "placeholderSkin": "CopyslListBox0e46dc929c0e643",
                "viewType": constants.LISTBOX_VIEW_TYPE_LISTVIEW
            });
            flxCuisines.add(lstBoxCuisines);
            var FlexContainer0f7db97dbf0b942 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "26.81%",
                "id": "FlexContainer0f7db97dbf0b942",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "skin": "CopyslFbox0d58639e9238845",
                "top": "-22.37%",
                "width": "100%",
                "zIndex": 1
            }, {}, {});
            FlexContainer0f7db97dbf0b942.setDefaultUnit(kony.flex.DP);
            FlexContainer0f7db97dbf0b942.add();
            flxContainer.add(flxCity, flxCuisines, FlexContainer0f7db97dbf0b942);
            var flxCityContainer2 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "30%",
                "id": "flxCityContainer2",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "skin": "CopyslFbox0e95d2fe2d4a34d",
                "top": "100%",
                "width": "100%",
                "zIndex": 50
            }, {}, {});
            flxCityContainer2.setDefaultUnit(kony.flex.DP);
            var segCity = new kony.ui.SegmentedUI2({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "data": [{
                    "lblCity": "City",
                    "lblLine": "Label",
                    "lblTitle": "Title"
                }, {
                    "lblCity": "City",
                    "lblLine": "Label",
                    "lblTitle": "Title"
                }, {
                    "lblCity": "City",
                    "lblLine": "Label",
                    "lblTitle": "Title"
                }],
                "groupCells": false,
                "height": "100%",
                "id": "segCity",
                "isVisible": true,
                "left": "0dp",
                "needPageIndicator": true,
                "onRowClick": controller.AS_Segment_g76dab97ca944831b7f522f10cb7c4be,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowFocusSkin": "seg2Focus",
                "rowSkin": "seg2Normal",
                "rowTemplate": "flxSegRoot",
                "scrollingEvents": {},
                "sectionHeaderSkin": "sliPhoneSegmentHeader",
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorColor": "64646400",
                "separatorRequired": true,
                "separatorThickness": 1,
                "showScrollbars": false,
                "top": "0dp",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {
                    "flxSegRoot": "flxSegRoot",
                    "lblCity": "lblCity",
                    "lblLine": "lblLine",
                    "lblTitle": "lblTitle"
                },
                "width": "99.07%",
                "zIndex": 1
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxCityContainer2.add(segCity);
            var flxRestaurantContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "70%",
                "id": "flxRestaurantContainer",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "skin": "slFbox",
                "top": "100%",
                "width": "100%",
                "zIndex": 20
            }, {}, {});
            flxRestaurantContainer.setDefaultUnit(kony.flex.DP);
            var segRestaurant = new kony.ui.SegmentedUI2({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "data": [{
                    "imgResIcon": "imagedrag.png",
                    "lblCuisines": "Cuisines",
                    "lblLine": "",
                    "lblRating": "4.5",
                    "lblResName": "Restaurant name"
                }, {
                    "imgResIcon": "imagedrag.png",
                    "lblCuisines": "Cuisines",
                    "lblLine": "",
                    "lblRating": "4.5",
                    "lblResName": "Restaurant name"
                }, {
                    "imgResIcon": "imagedrag.png",
                    "lblCuisines": "Cuisines",
                    "lblLine": "",
                    "lblRating": "4.5",
                    "lblResName": "Restaurant name"
                }],
                "groupCells": false,
                "height": "100%",
                "id": "segRestaurant",
                "isVisible": true,
                "left": "0dp",
                "needPageIndicator": true,
                "onRowClick": controller.AS_Segment_afa41cd7d6004aa5bd8c80fc46f6f50e,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowFocusSkin": "seg2Focus",
                "rowSkin": "seg2Normal",
                "rowTemplate": "flxRootContainer",
                "scrollingEvents": {},
                "sectionHeaderSkin": "sliPhoneSegmentHeader",
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorColor": "64646400",
                "separatorRequired": true,
                "separatorThickness": 1,
                "showScrollbars": false,
                "top": "0dp",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {
                    "flxRestaurantInfo": "flxRestaurantInfo",
                    "flxRootContainer": "flxRootContainer",
                    "flxTitle": "flxTitle",
                    "imgResIcon": "imgResIcon",
                    "lblCuisines": "lblCuisines",
                    "lblLine": "lblLine",
                    "lblRating": "lblRating",
                    "lblResName": "lblResName"
                },
                "width": "100%",
                "zIndex": 1
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxRestaurantContainer.add(segRestaurant);
            flxRoot.add(flxTitle, flxContainer, flxCityContainer2, flxRestaurantContainer);
            this.add(flxRoot);
        };
        return [{
            "addWidgets": addWidgetsfrmSearchRestaurant,
            "enabledForIdleTimeout": false,
            "id": "frmSearchRestaurant",
            "layoutType": kony.flex.FREE_FORM,
            "needAppMenu": false,
            "skin": "sknFrmGrey",
            "info": {
                "kuid": "f25fbbd0d5af4d229da1958ff693ee41"
            }
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": kony.flex.FREE_FORM,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {
            "footerOverlap": false,
            "headerOverlap": false,
            "menuPosition": constants.FORM_MENU_POSITION_AFTER_APPMENU,
            "retainScrollPosition": false,
            "titleBar": true,
            "titleBarSkin": "slTitleBar",
            "windowSoftInputMode": constants.FORM_ADJUST_PAN
        }]
    }
});