define({
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    AS_Image_a6d467ee5abc4a66b317ed6472c4a2c3: function AS_Image_a6d467ee5abc4a66b317ed6472c4a2c3(eventobject, x, y) {
        var self = this;
        this.showMenu();
    },
    AS_Segment_5df59f9c2d334da3a72011f5ffb8520b: function AS_Segment_5df59f9c2d334da3a72011f5ffb8520b(eventobject, sectionNumber, rowNumber) {
        var self = this;
        this.onMyRowClick();
    },
    AS_Button_f2b727fb77084e958bffbd1ea029e41f: function AS_Button_f2b727fb77084e958bffbd1ea029e41f(eventobject) {
        var self = this;
        this.navigateToFormProfile();
    },
    AS_Button_f3fd38261ceb4883bf113ff8cd2d9c12: function AS_Button_f3fd38261ceb4883bf113ff8cd2d9c12(eventobject) {
        var self = this;
        this.hideMenu();
    },
    AS_Button_80d8337ad975457784c8d6fd7a336e5d: function AS_Button_80d8337ad975457784c8d6fd7a336e5d(eventobject) {
        var self = this;
        this.getFavouriteRestaurant();
    },
    AS_Button_3817c3dc2db44de8b512d1f9937df796: function AS_Button_3817c3dc2db44de8b512d1f9937df796(eventobject) {
        var self = this;
        this.pushRegistration();
    },
    AS_Button_ab26757515d34db2a60f5ef2ffe46323: function AS_Button_ab26757515d34db2a60f5ef2ffe46323(eventobject) {
        var self = this;
        this.signOut();
    },
    AS_FlexContainer_7127bf2110594b479dd57e62f7142247: function AS_FlexContainer_7127bf2110594b479dd57e62f7142247(eventobject) {
        var self = this;
        this.dummyFun();
    },
    AS_Button_f5fe1698ed7047e6afea1840ce9fec6d: function AS_Button_f5fe1698ed7047e6afea1840ce9fec6d(eventobject) {
        var self = this;
        this.navigateToFormProfile();
    },
    AS_Button_i3c3cf468a22422ebd0d80e36f1d4fc2: function AS_Button_i3c3cf468a22422ebd0d80e36f1d4fc2(eventobject) {
        var self = this;
        this.hideMenu();
    },
    AS_Button_ef816ce4bbc449eb8ca143fd39785f0a: function AS_Button_ef816ce4bbc449eb8ca143fd39785f0a(eventobject) {
        var self = this;
        this.getFavouriteRestaurant();
    },
    AS_Button_ae429e0ea0bd47dd9024f84bfb6fe0d1: function AS_Button_ae429e0ea0bd47dd9024f84bfb6fe0d1(eventobject) {
        var self = this;
        this.hideMenu();
        pushRegistration.call(this);
    },
    AS_Button_ffffc62133ae4079af72c3f04b8ee88d: function AS_Button_ffffc62133ae4079af72c3f04b8ee88d(eventobject) {
        var self = this;
        this.signOut();
    },
    AS_Button_i431988f31484251a9a9eba0f70a9b8c: function AS_Button_i431988f31484251a9a9eba0f70a9b8c(eventobject) {
        var self = this;
        this.searchRestaurant();
    },
    AS_FlexContainer_bf1c5f2b09864185bd10b95fb07f94b2: function AS_FlexContainer_bf1c5f2b09864185bd10b95fb07f94b2(eventobject) {
        var self = this;
        self.AS_FlexContainer_e88fd6abbf1b49cdad910feff23d7328(eventobject);
    },
    AS_FlexContainer_f17a97fea8304cd2a7ac3c0af75c83b9: function AS_FlexContainer_f17a97fea8304cd2a7ac3c0af75c83b9(eventobject) {
        var self = this;
        this.masterFunction();
    },
    AS_Form_553c8effd5dd4e03b7bdf75b9c55a878: function AS_Form_553c8effd5dd4e03b7bdf75b9c55a878(eventobject) {
        var self = this;
        //this.setGestureRecognizer();
    },
    AS_Form_i6e21e49ff9d4016899d76612923a348: function AS_Form_i6e21e49ff9d4016899d76612923a348(eventobject) {
        var self = this;
        return callbackAndroidSetCallbacks.call(this);
    },
    AS_FlexContainer_e88fd6abbf1b49cdad910feff23d7328: function AS_FlexContainer_e88fd6abbf1b49cdad910feff23d7328(eventobject) {
        var self = this;
        return;
    }
});