define("frmResDetails", function() {
    return function(controller) {
        function addWidgetsfrmResDetails() {
            this.setDefaultUnit(kony.flex.DP);
            var flxTitle = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "40dp",
                "id": "flxTitle",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 2
            }, {}, {});
            flxTitle.setDefaultUnit(kony.flex.DP);
            var btnFavourite = new kony.ui.Button({
                "centerY": "50%",
                "focusSkin": "sknBtnFavourite",
                "height": "30dp",
                "id": "btnFavourite",
                "isVisible": true,
                "left": "10dp",
                "onClick": controller.AS_Button_35757ba08e0042db8e42402dc4f81253,
                "skin": "sknBtnFavourite",
                "top": "11dp",
                "width": "80dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "showProgressIndicator": true
            });
            var lblztitle = new kony.ui.Label({
                "centerX": "50%",
                "centerY": "50%",
                "id": "lblztitle",
                "isVisible": true,
                "skin": "sknLblTitle2",
                "text": "Details",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "textCopyable": false,
                "wrapping": constants.WIDGET_TEXT_WORD_WRAP
            });
            var btnHome = new kony.ui.Button({
                "centerY": "50%",
                "focusSkin": "sknBtnTrans",
                "height": "100%",
                "id": "btnHome",
                "isVisible": true,
                "onClick": controller.AS_Button_ca05cd8f5cf545cfab4f3bc54b9ba5c4,
                "right": "10dp",
                "skin": "sknBtnTrans",
                "text": "Home",
                "top": "1dp",
                "width": "70dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "showProgressIndicator": true
            });
            flxTitle.add(btnFavourite, lblztitle, btnHome);
            var flxRootContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxRootContainer",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "skin": "slFbox",
                "top": "40dp",
                "width": "100%",
                "zIndex": 1
            }, {}, {});
            flxRootContainer.setDefaultUnit(kony.flex.DP);
            var imgResIcon = new kony.ui.Image2({
                "centerX": "50%",
                "id": "imgResIcon",
                "isVisible": true,
                "left": 0,
                "skin": "slImage",
                "src": "imagedrag.png",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblRating = new kony.ui.Label({
                "height": "4%",
                "id": "lblRating",
                "isVisible": true,
                "right": "15dp",
                "skin": "sknLblRating",
                "text": "4.5",
                "top": "115dp",
                "width": "8%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "textCopyable": false,
                "wrapping": constants.WIDGET_TEXT_WORD_WRAP
            });
            var lblName = new kony.ui.Label({
                "id": "lblName",
                "isVisible": true,
                "left": "15dp",
                "skin": "sknLblResNameWhite",
                "text": "Restaurant name",
                "top": "27dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 2
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "textCopyable": false,
                "wrapping": constants.WIDGET_TEXT_WORD_WRAP
            });
            var flxInfoRoot = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "0dp",
                "clipBounds": true,
                "height": "70%",
                "id": "flxInfoRoot",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "skin": "sknFlxLightGrey",
                "top": "30%",
                "width": "100%",
                "zIndex": 1
            }, {}, {});
            flxInfoRoot.setDefaultUnit(kony.flex.DP);
            var flxCusinies = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "60dp",
                "id": "flxCusinies",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0%",
                "skin": "sknFlxWhite",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {}, {});
            flxCusinies.setDefaultUnit(kony.flex.DP);
            var Label09e3a6d8dac074c = new kony.ui.Label({
                "height": "30dp",
                "id": "Label09e3a6d8dac074c",
                "isVisible": true,
                "left": "5dp",
                "skin": "sknLblResInfo",
                "text": "Cuisines",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "textCopyable": false,
                "wrapping": constants.WIDGET_TEXT_WORD_WRAP
            });
            var lblCusines = new kony.ui.Label({
                "height": "30dp",
                "id": "lblCusines",
                "isVisible": true,
                "left": "5dp",
                "skin": "sknLblCuisines",
                "text": "Label",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "textCopyable": false,
                "wrapping": constants.WIDGET_TEXT_WORD_WRAP
            });
            flxCusinies.add(Label09e3a6d8dac074c, lblCusines);
            var CopylblLine014ea075be44e41 = new kony.ui.Label({
                "bottom": "0%",
                "height": "1dp",
                "id": "CopylblLine014ea075be44e41",
                "isVisible": true,
                "left": "5dp",
                "skin": "sknLblLine",
                "width": "97%",
                "zIndex": 2
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "textCopyable": false,
                "wrapping": constants.WIDGET_TEXT_WORD_WRAP
            });
            var flxRating = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "60dp",
                "id": "flxRating",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0%",
                "skin": "sknFlxWhite",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {}, {});
            flxRating.setDefaultUnit(kony.flex.DP);
            var lblRatingTitle = new kony.ui.Label({
                "height": "30dp",
                "id": "lblRatingTitle",
                "isVisible": true,
                "left": "5dp",
                "skin": "sknLblResInfo",
                "text": "Rating",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "textCopyable": false,
                "wrapping": constants.WIDGET_TEXT_WORD_WRAP
            });
            var lblUserRating = new kony.ui.Label({
                "id": "lblUserRating",
                "isVisible": true,
                "left": "5dp",
                "skin": "sknLblCuisines",
                "text": "Label",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "textCopyable": false,
                "wrapping": constants.WIDGET_TEXT_WORD_WRAP
            });
            var Label04772d85fe30e4b = new kony.ui.Label({
                "id": "Label04772d85fe30e4b",
                "isVisible": false,
                "left": "22dp",
                "skin": "slLabel",
                "text": "votes",
                "top": "14dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "textCopyable": false,
                "wrapping": constants.WIDGET_TEXT_WORD_WRAP
            });
            var lblVotes = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblVotes",
                "isVisible": false,
                "left": "4dp",
                "skin": "slLabel",
                "text": "50",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "textCopyable": false,
                "wrapping": constants.WIDGET_TEXT_WORD_WRAP
            });
            flxRating.add(lblRatingTitle, lblUserRating, Label04772d85fe30e4b, lblVotes);
            var CopylblLine0aced769789dd40 = new kony.ui.Label({
                "bottom": "0%",
                "height": "1dp",
                "id": "CopylblLine0aced769789dd40",
                "isVisible": true,
                "left": "5dp",
                "skin": "sknLblLine",
                "text": "Label",
                "width": "97%",
                "zIndex": 2
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "textCopyable": false,
                "wrapping": constants.WIDGET_TEXT_WORD_WRAP
            });
            var flxCost = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "60dp",
                "id": "flxCost",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0%",
                "skin": "sknFlxWhite",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {}, {});
            flxCost.setDefaultUnit(kony.flex.DP);
            var lblCostTitle = new kony.ui.Label({
                "height": "30dp",
                "id": "lblCostTitle",
                "isVisible": true,
                "left": "5dp",
                "skin": "sknLblResInfo",
                "text": "Cost",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "textCopyable": false,
                "wrapping": constants.WIDGET_TEXT_WORD_WRAP
            });
            var lblCost = new kony.ui.Label({
                "height": "30dp",
                "id": "lblCost",
                "isVisible": true,
                "left": "5dp",
                "skin": "sknLblCuisines",
                "text": "Label",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "textCopyable": false,
                "wrapping": constants.WIDGET_TEXT_WORD_WRAP
            });
            flxCost.add(lblCostTitle, lblCost);
            var CopylblLine04821f55962dc44 = new kony.ui.Label({
                "bottom": "0%",
                "height": "1dp",
                "id": "CopylblLine04821f55962dc44",
                "isVisible": true,
                "left": "5dp",
                "skin": "sknLblLine",
                "width": "97%",
                "zIndex": 2
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "textCopyable": false,
                "wrapping": constants.WIDGET_TEXT_WORD_WRAP
            });
            var flxAddress = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "120dp",
                "id": "flxAddress",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "skin": "sknFlxWhite",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {}, {});
            flxAddress.setDefaultUnit(kony.flex.DP);
            var lblAddressTitle = new kony.ui.Label({
                "height": "30dp",
                "id": "lblAddressTitle",
                "isVisible": true,
                "left": "5dp",
                "skin": "sknLblResInfo",
                "text": "Address",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "textCopyable": false,
                "wrapping": constants.WIDGET_TEXT_WORD_WRAP
            });
            var lblAddress = new kony.ui.Label({
                "id": "lblAddress",
                "isVisible": true,
                "left": "5dp",
                "skin": "sknLblCuisines",
                "text": "Address",
                "top": "30dp",
                "width": "98%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "textCopyable": false,
                "wrapping": constants.WIDGET_TEXT_WORD_WRAP
            });
            var btnMap = new kony.ui.Button({
                "focusSkin": "sknBtnMap",
                "id": "btnMap",
                "isVisible": true,
                "onClick": controller.AS_Button_99cb95197af140b284b78f44dc2e6d1f,
                "right": "10dp",
                "skin": "sknBtnMap",
                "top": "0dp",
                "width": "40dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "showProgressIndicator": true
            });
            flxAddress.add(lblAddressTitle, lblAddress, btnMap);
            var lblLine = new kony.ui.Label({
                "bottom": "0%",
                "height": "1dp",
                "id": "lblLine",
                "isVisible": true,
                "left": "0dp",
                "skin": "slLabel",
                "text": "Label",
                "width": "100%",
                "zIndex": 2
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "textCopyable": false,
                "wrapping": constants.WIDGET_TEXT_WORD_WRAP
            });
            flxInfoRoot.add(flxCusinies, CopylblLine014ea075be44e41, flxRating, CopylblLine0aced769789dd40, flxCost, CopylblLine04821f55962dc44, flxAddress, lblLine);
            var imgFavourite = new kony.ui.Image2({
                "height": "30dp",
                "id": "imgFavourite",
                "isVisible": true,
                "onTouchEnd": controller.AS_Image_20209c86168d4b80be10829733e71b6f,
                "right": "15dp",
                "skin": "slImage",
                "src": "option1.png",
                "top": "27dp",
                "width": "30dp",
                "zIndex": 2
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxRootContainer.add(imgResIcon, lblRating, lblName, flxInfoRoot, imgFavourite);
            this.add(flxTitle, flxRootContainer);
        };
        return [{
            "addWidgets": addWidgetsfrmResDetails,
            "enabledForIdleTimeout": false,
            "id": "frmResDetails",
            "layoutType": kony.flex.FREE_FORM,
            "needAppMenu": false,
            "skin": "sknFrmGrey",
            "title": "Details",
            "info": {
                "kuid": "3e8d7aa94f854182a0bf598ffd5826f5"
            }
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": kony.flex.FREE_FORM,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {
            "configureExtendBottom": false,
            "configureExtendTop": false,
            "configureStatusBarStyle": false,
            "footerOverlap": false,
            "formTransparencyDuringPostShow": "100",
            "headerOverlap": false,
            "inputAccessoryViewType": constants.FORM_INPUTACCESSORYVIEW_CANCEL,
            "needsIndicatorDuringPostShow": false,
            "retainScrollPosition": false,
            "titleBar": true,
            "titleBarConfig": {
                "renderTitleText": true,
                "prevFormTitle": false,
                "titleBarLeftSideView": "button",
                "labelLeftSideView": "Back",
                "titleBarRightSideView": "button",
                "labelRightSideView": "Edit"
            },
            "titleBarSkin": "sknLblFrmTitle"
        }]
    }
});