define("frmHome", function() {
    return function(controller) {
        function addWidgetsfrmHome() {
            this.setDefaultUnit(kony.flex.DP);
            var flxRoot = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxRoot",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 2
            }, {}, {});
            flxRoot.setDefaultUnit(kony.flex.DP);
            var flxTitle = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "9%",
                "id": "flxTitle",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 2
            }, {}, {});
            flxTitle.setDefaultUnit(kony.flex.DP);
            var lblTitle = new kony.ui.Label({
                "centerX": "50%",
                "centerY": "50%",
                "id": "lblTitle",
                "isVisible": true,
                "skin": "sknLblTitle2",
                "text": "Home",
                "textStyle": {
                    "letterSpacing": 0,
                    "strikeThrough": false
                },
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "textCopyable": false
            });
            var imgMenu = new kony.ui.Image2({
                "centerY": "50%",
                "height": "30dp",
                "id": "imgMenu",
                "isVisible": true,
                "left": "10dp",
                "onTouchEnd": controller.AS_Image_a6d467ee5abc4a66b317ed6472c4a2c3,
                "skin": "slImage",
                "src": "burger.png",
                "top": "0dp",
                "width": "30dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxTitle.add(lblTitle, imgMenu);
            var flxRootContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "91%",
                "id": "flxRootContainer",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "skin": "slFbox",
                "top": "9%",
                "width": "100%",
                "zIndex": 1
            }, {}, {});
            flxRootContainer.setDefaultUnit(kony.flex.DP);
            var segRestaurant = new kony.ui.SegmentedUI2({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "data": [{
                    "imgResIcon": "imagedrag.png",
                    "lblCuisines": "Cuisines",
                    "lblLine": "Label",
                    "lblRating": "Rating",
                    "lblResName": "Restaurant name"
                }, {
                    "imgResIcon": "imagedrag.png",
                    "lblCuisines": "Cuisines",
                    "lblLine": "Label",
                    "lblRating": "Rating",
                    "lblResName": "Restaurant name"
                }, {
                    "imgResIcon": "imagedrag.png",
                    "lblCuisines": "Cuisines",
                    "lblLine": "Label",
                    "lblRating": "Rating",
                    "lblResName": "Restaurant name"
                }],
                "groupCells": false,
                "height": "100%",
                "id": "segRestaurant",
                "isVisible": true,
                "left": "0dp",
                "needPageIndicator": true,
                "onRowClick": controller.AS_Segment_5df59f9c2d334da3a72011f5ffb8520b,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowFocusSkin": "Copyseg0ad33c17cd47345",
                "rowSkin": "Copyseg0ad33c17cd47345",
                "rowTemplate": "flxRootContainer",
                "scrollingEvents": {},
                "sectionHeaderSkin": "sliPhoneSegmentHeader",
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorRequired": false,
                "showScrollbars": false,
                "top": "0dp",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {
                    "flxRestaurantInfo": "flxRestaurantInfo",
                    "flxRootContainer": "flxRootContainer",
                    "flxTitle": "flxTitle",
                    "imgResIcon": "imgResIcon",
                    "lblCuisines": "lblCuisines",
                    "lblLine": "lblLine",
                    "lblRating": "lblRating",
                    "lblResName": "lblResName"
                },
                "width": "100%",
                "zIndex": 1
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxRootContainer.add(segRestaurant);
            var km6678728a4024faa8384abaa0578f91c = new kony.ui.FlexContainer({
                "clipBounds": true,
                "isMaster": true,
                "height": "100%",
                "id": "MasterMenu",
                "layoutType": kony.flex.FREE_FORM,
                "left": "-100%",
                "onClick": controller.AS_FlexContainer_bf1c5f2b09864185bd10b95fb07f94b2,
                "postShow": controller.AS_FlexContainer_f17a97fea8304cd2a7ac3c0af75c83b9,
                "width": "100%",
                "zIndex": 10,
                "isVisible": true,
                "skin": "slFbox",
                "top": "0dp"
            }, {}, {});
            km6678728a4024faa8384abaa0578f91c.setDefaultUnit(kony.flex.DP);
            var km8e207be3ce64deabe0aba39a8e8a854 = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "100%",
                "id": "flxMenuContainer",
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "width": "100%",
                "zIndex": 20,
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "isVisible": true,
                "left": "0%",
                "skin": "sknFl",
                "top": "0dp"
            }, {}, {});
            km8e207be3ce64deabe0aba39a8e8a854.setDefaultUnit(kony.flex.DP);
            var km71d852727a546269205b9d8a829d750 = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "100%",
                "id": "flxMenuRoot",
                "layoutType": kony.flex.FLOW_VERTICAL,
                "width": "70%",
                "zIndex": 1,
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "isVisible": true,
                "left": "0dp",
                "skin": "sknFlxDarkGrey",
                "top": "0dp"
            }, {}, {});
            km71d852727a546269205b9d8a829d750.setDefaultUnit(kony.flex.DP);
            var kmcb6125bcb564908ba383bd051b8af88 = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "180dp",
                "id": "flxProfile",
                "layoutType": kony.flex.FREE_FORM,
                "width": "100%",
                "zIndex": 1,
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "isVisible": true,
                "left": "0dp",
                "skin": "slFbox",
                "top": "0dp"
            }, {}, {});
            kmcb6125bcb564908ba383bd051b8af88.setDefaultUnit(kony.flex.DP);
            var kma2431fd394c4992a10f34f3168bee6a = new kony.ui.Image2({
                "height": "100%",
                "id": "imgLogo",
                "src": "imagedrag.png",
                "width": "100%",
                "zIndex": 1,
                "centerX": "50%",
                "centerY": "50%",
                "isVisible": true,
                "skin": "slImage"
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            kmcb6125bcb564908ba383bd051b8af88.add(kma2431fd394c4992a10f34f3168bee6a);
            var km7bfa79a012c445085c52004bdcdb123 = new kony.ui.Label({
                "height": "1dp",
                "id": "lblLine",
                "textStyle": {},
                "width": "80%",
                "zIndex": 1,
                "centerX": "50%",
                "isVisible": true,
                "left": "0",
                "skin": "sknLblMenuLine",
                "top": "0"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "textCopyable": false
            });
            var km5cca7df7bff4847a0b2d2c2f413e288 = new kony.ui.Button({
                "height": "50dp",
                "id": "btnProfile",
                "onClick": controller.AS_Button_f5fe1698ed7047e6afea1840ce9fec6d,
                "text": "Profile",
                "width": "260dp",
                "zIndex": 1,
                "centerX": "50%",
                "focusSkin": "sknBtnMenuFocus",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknBtnMenu"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var kmfeb63a96fc1489682a4e02569d7f907 = new kony.ui.Label({
                "height": "1dp",
                "id": "lblLine2",
                "textStyle": {},
                "width": "80%",
                "zIndex": 1,
                "centerX": "50%",
                "isVisible": true,
                "left": "0",
                "skin": "sknLblMenuLine",
                "top": "0"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "textCopyable": false
            });
            var kmd5b3bb6f5824edebfae9488d242bfcb = new kony.ui.Button({
                "height": "50dp",
                "id": "btnNearByRestaurant",
                "onClick": controller.AS_Button_i3c3cf468a22422ebd0d80e36f1d4fc2,
                "text": "Near by restaurant",
                "width": "260dp",
                "zIndex": 1,
                "centerX": "50%",
                "focusSkin": "sknBtnMenuFocus",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknBtnMenu",
                "top": "0"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var km6b7dae3c74540719116058cb0387b30 = new kony.ui.Label({
                "height": "1dp",
                "id": "lblLine3",
                "textStyle": {},
                "width": "80%",
                "zIndex": 1,
                "centerX": "50%",
                "isVisible": true,
                "left": "0",
                "skin": "sknLblMenuLine",
                "top": "0"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "textCopyable": false
            });
            var km1b062b4ab34494781b08a0a056468a2 = new kony.ui.Button({
                "height": "50dp",
                "id": "btnFavourite",
                "onClick": controller.AS_Button_ef816ce4bbc449eb8ca143fd39785f0a,
                "text": "Favourite",
                "width": "100%",
                "zIndex": 1,
                "centerX": "50%",
                "focusSkin": "sknBtnMenuFocus",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknBtnMenu",
                "top": "0dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var kma81f684c10f43c682c9a86a750763bc = new kony.ui.Label({
                "height": "1dp",
                "id": "lblLne4",
                "textStyle": {},
                "width": "80%",
                "zIndex": 1,
                "centerX": "50%",
                "isVisible": true,
                "left": "0",
                "skin": "sknLblMenuLine",
                "top": "0"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "textCopyable": false
            });
            var km45b2f4338c6457aa55b607260fba191 = new kony.ui.Button({
                "height": "50dp",
                "id": "btnSubscribe",
                "onClick": controller.AS_Button_ae429e0ea0bd47dd9024f84bfb6fe0d1,
                "text": "Subscribe",
                "width": "260dp",
                "zIndex": 1,
                "centerX": "50%",
                "focusSkin": "sknBtnMenuFocus",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknBtnMenu",
                "top": "0"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var kmc43d34706ce42f19ab09e23ea901072 = new kony.ui.Label({
                "height": "1dp",
                "id": "lblLine5",
                "textStyle": {},
                "width": "80%",
                "zIndex": 1,
                "centerX": "50%",
                "isVisible": true,
                "left": "0",
                "skin": "sknLblMenuLine",
                "top": "0"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "textCopyable": false
            });
            var kmf6118b269f244109d547c696a900cd8 = new kony.ui.Button({
                "height": "50dp",
                "id": "btnSignOut",
                "onClick": controller.AS_Button_ffffc62133ae4079af72c3f04b8ee88d,
                "text": "Sign Out",
                "width": "260dp",
                "zIndex": 1,
                "centerX": "50%",
                "focusSkin": "sknBtnMenuFocus",
                "isVisible": true,
                "skin": "sknBtnTrans",
                "top": "0dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var kmd4c0768741245f18ef8281b2e9d8d43 = new kony.ui.Label({
                "height": "1dp",
                "id": "CopylblLine0fa063694c34c42",
                "textStyle": {},
                "width": "80%",
                "zIndex": 1,
                "centerX": "50%",
                "isVisible": true,
                "left": "0",
                "skin": "sknLblMenuLine",
                "top": "0"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "textCopyable": false
            });
            var km868a7d97ec4450d9b6c034b8e67ad1b = new kony.ui.Button({
                "height": "50dp",
                "id": "btnSearch",
                "onClick": controller.AS_Button_i431988f31484251a9a9eba0f70a9b8c,
                "text": "Search",
                "width": "260dp",
                "zIndex": 20,
                "bottom": "0dp",
                "focusSkin": "sknBtnMenuFocus",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknBtnTrans"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            km71d852727a546269205b9d8a829d750.add(kmcb6125bcb564908ba383bd051b8af88, km7bfa79a012c445085c52004bdcdb123, km5cca7df7bff4847a0b2d2c2f413e288, kmfeb63a96fc1489682a4e02569d7f907, kmd5b3bb6f5824edebfae9488d242bfcb, km6b7dae3c74540719116058cb0387b30, km1b062b4ab34494781b08a0a056468a2, kma81f684c10f43c682c9a86a750763bc, km45b2f4338c6457aa55b607260fba191, kmc43d34706ce42f19ab09e23ea901072, kmf6118b269f244109d547c696a900cd8, kmd4c0768741245f18ef8281b2e9d8d43, km868a7d97ec4450d9b6c034b8e67ad1b);
            var kmac6cd0914fe464e885809fe074f6546 = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "100%",
                "id": "flxShadow",
                "layoutType": kony.flex.FREE_FORM,
                "width": "30%",
                "zIndex": 1,
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "isVisible": true,
                "left": "0dp",
                "skin": "sknFl",
                "top": "0dp"
            }, {}, {});
            kmac6cd0914fe464e885809fe074f6546.setDefaultUnit(kony.flex.DP);
            kmac6cd0914fe464e885809fe074f6546.add();
            km8e207be3ce64deabe0aba39a8e8a854.add(km71d852727a546269205b9d8a829d750, kmac6cd0914fe464e885809fe074f6546);
            km6678728a4024faa8384abaa0578f91c.add(km8e207be3ce64deabe0aba39a8e8a854);
            flxRoot.add(flxTitle, flxRootContainer, km6678728a4024faa8384abaa0578f91c);
            this.add(flxRoot);
        };
        return [{
            "addWidgets": addWidgetsfrmHome,
            "enabledForIdleTimeout": false,
            "id": "frmHome",
            "init": controller.AS_Form_553c8effd5dd4e03b7bdf75b9c55a878,
            "layoutType": kony.flex.FREE_FORM,
            "needAppMenu": false,
            "postShow": controller.AS_Form_i6e21e49ff9d4016899d76612923a348,
            "skin": "sknFrmGrey",
            "title": "Restaurants",
            "info": {
                "kuid": "9b74c11daa304d118f07a119e787eb8b"
            }
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": kony.flex.FREE_FORM,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {
            "footerOverlap": false,
            "headerOverlap": false,
            "menuPosition": constants.FORM_MENU_POSITION_AFTER_APPMENU,
            "retainScrollPosition": false,
            "titleBar": false,
            "titleBarSkin": "sknLblFrmTitle",
            "windowSoftInputMode": constants.FORM_ADJUST_PAN
        }]
    }
});