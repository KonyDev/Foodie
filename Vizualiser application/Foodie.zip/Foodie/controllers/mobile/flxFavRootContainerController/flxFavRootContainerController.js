define({ 
	removeRestaurant:function(widget, context){
		kony.print("widget :"+JSON.stringify(widget));
  		kony.print("context :"+JSON.stringify(context));
  		//alert(JSON.stringify(context["widgetInfo"]["selectedRowItems"][0]["primaryKeyValueMap"]));
      this.executeOnParent("removeFavouriteRestaurant",context);
	}
 });