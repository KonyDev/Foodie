ALTER TABLE `Restaurant`
	CHANGE `resturant_id` `restaurant_id` VARCHAR(50) NOT NULL,
	DROP PRIMARY KEY,
	ADD PRIMARY KEY(`device_id`,`restaurant_id`);
