define({
    "login": function(provider) {
        //this.login("GoogleOauth");
        try {
            var navigateObj = new kony.mvc.Navigation("frmBrowser");
            var data = {
                "provider": "GoogleOauth",
                "operation": "login"
            };
            navigateObj.navigate(data);
        } catch (exp) {
            kony.print(JSON.stringify(exp));
        }
    },
    "AS_Button_5ad572826c524e8a90870422b3df6054": function AS_Button_5ad572826c524e8a90870422b3df6054(eventobject) {
        var self = this;
        this.login(provider.googleProvider);
    }
})