define({
    "removeRestaurant": function(widget, context) {
        kony.print("widget :" + JSON.stringify(widget));
        kony.print("context :" + JSON.stringify(context));
        //alert(JSON.stringify(context["widgetInfo"]["selectedRowItems"][0]["primaryKeyValueMap"]));
        this.executeOnParent("removeFavouriteRestaurant", context);
    },
    "AS_FlexContainer_c89261059d6743428e34064233f944c2": function AS_FlexContainer_c89261059d6743428e34064233f944c2(eventobject, context) {
        var self = this;
        this.removeRestaurant(eventobject, context);
    }
})