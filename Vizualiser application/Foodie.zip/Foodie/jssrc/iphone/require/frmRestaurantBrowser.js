define("frmRestaurantBrowser", function() {
    return function(controller) {
        function addWidgetsfrmRestaurantBrowser() {
            this.setDefaultUnit(kony.flex.DP);
            var browser = new kony.ui.Browser({
                "centerX": "50%",
                "centerY": "50%",
                "detectTelNumber": true,
                "enableZoom": false,
                "height": "100%",
                "htmlString": "Browser",
                "id": "browser",
                "isVisible": true,
                "width": "100%",
                "zIndex": 1
            }, {}, {});
            this.add(browser);
        };
        return [{
            "addWidgets": addWidgetsfrmRestaurantBrowser,
            "enabledForIdleTimeout": false,
            "id": "frmRestaurantBrowser",
            "layoutType": kony.flex.FREE_FORM,
            "needAppMenu": false,
            "skin": "slForm",
            "info": {
                "kuid": "af0f657875aa4dca94b71ebe7ea783e0"
            }
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": kony.flex.FREE_FORM,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {
            "configureExtendBottom": false,
            "configureExtendTop": false,
            "configureStatusBarStyle": false,
            "footerOverlap": false,
            "formTransparencyDuringPostShow": "100",
            "headerOverlap": false,
            "inputAccessoryViewType": constants.FORM_INPUTACCESSORYVIEW_CANCEL,
            "needsIndicatorDuringPostShow": false,
            "retainScrollPosition": false,
            "titleBar": false,
            "titleBarSkin": "slTitleBar"
        }]
    }
});