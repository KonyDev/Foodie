define({
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    AS_Button_35757ba08e0042db8e42402dc4f81253: function AS_Button_35757ba08e0042db8e42402dc4f81253(eventobject) {
        var self = this;
        this.getFavouriteRestaurant();
    },
    AS_Button_ca05cd8f5cf545cfab4f3bc54b9ba5c4: function AS_Button_ca05cd8f5cf545cfab4f3bc54b9ba5c4(eventobject) {
        var self = this;
        this.navigateTofrmHome();
    },
    AS_Button_gccb6d5ce90549eeb3831b46f0668c77: function AS_Button_gccb6d5ce90549eeb3831b46f0668c77(eventobject) {
        var self = this;
        this.showRestaurantMenu();
    },
    AS_Image_f3e6d1ce516a4bc5908f5d3721573ea8: function AS_Image_f3e6d1ce516a4bc5908f5d3721573ea8(eventobject, x, y) {
        var self = this;
        this.makeRestaurantFavourite();
    },
    AS_Button_g076c3717f304f15a92b480da27a7495: function AS_Button_g076c3717f304f15a92b480da27a7495(eventobject) {
        var self = this;
        this.locateRestaurant();
    },
    AS_FlexContainer_c00e106eda614b09b4aebff533c06a9f: function AS_FlexContainer_c00e106eda614b09b4aebff533c06a9f(eventobject) {
        var self = this;
        this.showRestaurantMenu();
    }
});