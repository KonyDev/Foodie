define("frmMap", function() {
    return function(controller) {
        function addWidgetsfrmMap() {
            this.setDefaultUnit(kony.flex.DP);
            var mapLocation = new kony.ui.Map({
                "calloutTemplate": "flxMapTmpRootContiner",
                "calloutWidth": 80,
                "defaultPinImage": "pinb.png",
                "height": "91%",
                "id": "mapLocation",
                "isVisible": true,
                "left": "0dp",
                "provider": constants.MAP_PROVIDER_GOOGLE,
                "top": "9%",
                "widgetDataMapForCallout": {
                    "btnMapTemplate": "btnMapTemplate",
                    "flxMapTmpRootContiner": "flxMapTmpRootContiner",
                    "imgIcon": "imgIcon",
                    "lblCusines": "lblCusines",
                    "lblLine": "lblLine",
                    "lblLine2": "lblLine2",
                    "lblName": "lblName",
                    "lblRating": "lblRating"
                },
                "width": "100%",
                "zIndex": 1
            }, {}, {
                "mode": constants.MAP_VIEW_MODE_NORMAL,
                "showCurrentLocation": constants.MAP_VIEW_SHOW_CURRENT_LOCATION_NONE,
                "zoomLevel": 20
            });
            var flxTitle = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "9%",
                "id": "flxTitle",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 2
            }, {}, {});
            flxTitle.setDefaultUnit(kony.flex.DP);
            var btnFavourite = new kony.ui.Button({
                "centerY": "50%",
                "focusSkin": "slButtonGlossRed",
                "height": "30dp",
                "id": "btnFavourite",
                "isVisible": true,
                "left": "10dp",
                "onClick": controller.AS_Button_e9bb141705214ebfae8d61380c33c2b1,
                "skin": "sknBtnFavourite",
                "top": "11dp",
                "width": "80dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "showProgressIndicator": true
            });
            var lblztitle = new kony.ui.Label({
                "centerX": "50%",
                "centerY": "50%",
                "id": "lblztitle",
                "isVisible": true,
                "skin": "sknLblTitle2",
                "text": "Details",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "textCopyable": false,
                "wrapping": constants.WIDGET_TEXT_WORD_WRAP
            });
            var btnHome = new kony.ui.Button({
                "centerY": "50%",
                "focusSkin": "sknBtnTrans",
                "height": "100%",
                "id": "btnHome",
                "isVisible": true,
                "onClick": controller.AS_Button_1f93c31c271f4b1f8abb09ea642814aa,
                "right": "10dp",
                "skin": "sknBtnTrans",
                "text": "Home",
                "top": "1dp",
                "width": "70dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "showProgressIndicator": true
            });
            flxTitle.add(btnFavourite, lblztitle, btnHome);
            this.add(mapLocation, flxTitle);
        };
        return [{
            "addWidgets": addWidgetsfrmMap,
            "enabledForIdleTimeout": false,
            "id": "frmMap",
            "layoutType": kony.flex.FREE_FORM,
            "needAppMenu": false,
            "skin": "sknFrmGrey",
            "title": "Location",
            "info": {
                "kuid": "60245041ff8b499caba9091f02656cbc"
            }
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": kony.flex.FREE_FORM,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {
            "configureExtendBottom": false,
            "configureExtendTop": false,
            "configureStatusBarStyle": false,
            "footerOverlap": false,
            "formTransparencyDuringPostShow": "100",
            "headerOverlap": false,
            "inputAccessoryViewType": constants.FORM_INPUTACCESSORYVIEW_CANCEL,
            "needsIndicatorDuringPostShow": false,
            "retainScrollPosition": false,
            "titleBar": false,
            "titleBarSkin": "sknLblFrmTitle"
        }]
    }
});