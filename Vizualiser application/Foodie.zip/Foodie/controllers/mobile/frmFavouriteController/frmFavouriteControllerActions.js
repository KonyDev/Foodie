define({
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    AS_Button_f1f1410203244258a33f3c2e49cd4d11: function AS_Button_f1f1410203244258a33f3c2e49cd4d11(eventobject) {
        var self = this;
        this.navigateTofrmHome();
    },
    AS_Segment_a6ad63bb0a4844e0982c8d98b1fcc8d6: function AS_Segment_a6ad63bb0a4844e0982c8d98b1fcc8d6(eventobject, sectionNumber, rowNumber) {
        var self = this;
        this.fetchRestaurant();
    }
});