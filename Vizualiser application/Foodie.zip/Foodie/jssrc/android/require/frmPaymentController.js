define({
    "navigateTofrmHome": function() {
        try {
            var navigateObj = new kony.mvc.Navigation("frmHome");
            navigateObj.navigate();
        } catch (exp) {
            kony.print(JSON.stringify(exp));
        }
    },
    "AS_Button_ga709817d4fd4e349048942f3d6e8370": function AS_Button_ga709817d4fd4e349048942f3d6e8370(eventobject) {
        var self = this;
        this.navigateTofrmHome();
    }
})