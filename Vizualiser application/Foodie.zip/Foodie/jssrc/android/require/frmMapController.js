define({
    "btnClick": function btnClick() {
        alert("clicked");
    },
    "onNavigate": function(restaurantObj) {
        var controlerScope = this;
        var locationList = [];
        var location = new Object();
        location = {
            "lat": restaurantObj["locationObj"][0]["latitude"],
            "lon": restaurantObj["locationObj"][0]["longitude"],
            "calloutData": {
                "lblName": restaurantObj["name"],
                "lblRating": restaurantObj["user_rating"][0]["aggregate_rating"],
                "lblCusines": restaurantObj["cuisines"],
                "imgIcon": {
                    "src": restaurantObj["thumb"]
                },
                "btnMapTemplate": {
                    "text": "Get Directions",
                    "onClick": controlerScope.btnClick
                }
            },
            "image": "restaurant.png",
            // "name":restaurantObj["name"],
            //"desc":" ",
            "showcallout": true
        };
        var deviceLocation = new Object();
        deviceLocation = {
            "lat": RESTAURANT_CONFIG.LATITUDE,
            "lon": RESTAURANT_CONFIG.LONGITUDE,
            "image": "pinb.png",
            "name": "current location",
            "desc": " ",
            //"calloutData": {"lblName":"ABC"},
            "showcallout": true
        };
        locationList.push(location);
        locationList.push(deviceLocation);
        this.view.mapLocation.containerHeight = 100;
        this.view.mapLocation.locationData = locationList;
        this.view.mapLocation.navigateTo(0, true);
    },
    "navigateTofrmFavourite": function() {
        try {
            var navigateTofrmMap = new kony.mvc.Navigation("frmFavourite");
            navigateTofrmMap.navigate();
        } catch (exp) {
            kony.print(JSON.stringify(exp));
        }
    },
    "navigateTofrmHome": function() {
        try {
            var navigateObj = new kony.mvc.Navigation("frmHome");
            navigateObj.navigate();
        } catch (exp) {
            kony.print(JSON.stringify(exp));
        }
    },
    "getFavouriteRestaurant": function() {
        var params = {};
        params.queryParams = {
            "$filter": "device_id eq " + "'" + kony.os.deviceInfo().deviceid + "'"
        };
        var navigateTofrmFavourite = new kony.mvc.Navigation("frmFavourite");
        var modelContext = new kony.model.ModelContext();
        modelContext.setRequestOptions("segRestaurant", params);
        navigateTofrmFavourite.setFormConfig(frmFavouriteConfig);
        navigateTofrmFavourite.setModelContext(modelContext);
        try {
            navigateTofrmFavourite.navigate();
        } catch (exp) {
            kony.print("Error in navigating the form");
        }
    },
    "getDirection": function(widget, data) {
        alert("setting direction");
    },
    "AS_Button_e9bb141705214ebfae8d61380c33c2b1": function AS_Button_e9bb141705214ebfae8d61380c33c2b1(eventobject) {
        var self = this;
        this.getFavouriteRestaurant();
    },
    "AS_Button_1f93c31c271f4b1f8abb09ea642814aa": function AS_Button_1f93c31c271f4b1f8abb09ea642814aa(eventobject) {
        var self = this;
        this.navigateTofrmHome();
    }
})