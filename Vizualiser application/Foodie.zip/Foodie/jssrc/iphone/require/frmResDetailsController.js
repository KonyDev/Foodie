define({
    "restaurantObj": {},
    "showRestaurantMenu": function() {
        try {
            var navigateObj = new kony.mvc.Navigation("frmRestaurantBrowser");
            navigateObj.navigate(this.restaurantObj);
        } catch (exp) {
            kony.print(JSON.stringify(exp));
        }
    },
    "onNavigate": function(restaurantParameter) {
        var restaurant;
        if (restaurantParameter !== undefined) {
            this.restaurantObj = restaurantParameter;
            restaurant = restaurantParameter;
        } else {
            restaurant = this.restaurantObj;
        }
        kony.print("in the onNavigate of frmResDetails :" + JSON.stringify(restaurant));
        this.view.imgResIcon.src = restaurant["featured_image"];
        this.view.lblRating.text = restaurant["user_rating"][0]["aggregate_rating"];
        this.view.lblName.text = restaurant["name"];
        this.view.lblCusines.text = restaurant["cuisines"];
        this.view.lblUserRating.text = restaurant["user_rating"][0]["rating_text"];
        this.view.lblVotes.text = restaurant["user_rating"][0]["votes"];
        this.view.lblAddress.text = restaurant["locationObj"][0]["address111"];
        this.view.lblCost.text = restaurant["currency"] + " " + restaurant["average_cost_for_two"] + " for 2 people.";
    },
    "makeRestaurantFavourite": function() {
        var controllerScope = this;

        function successCB(dataModel) {
            var resDataObject = new kony.sdk.dto.DataObject("Restaurant");
            var restaurant = {};
            restaurant["aggregate_rating"] = controllerScope.restaurantObj["user_rating"][0]["aggregate_rating"];
            restaurant["cuisines"] = controllerScope.restaurantObj["cuisines"];
            restaurant["device_id"] = kony.os.deviceInfo().deviceid;
            restaurant["name"] = controllerScope.restaurantObj["name"];
            restaurant["restaurant_id"] = controllerScope.restaurantObj["id"];
            restaurant["thumb"] = controllerScope.restaurantObj["thumb"];
            resDataObject.setRecord(restaurant);
            dataModel.create({
                dataObject: resDataObject
            }, function(successResponse) {
                kony.print("$$$$$$$$ creation success $$$$$$$" + JSON.stringify(successResponse))
            }, function(errorResponse) {
                kony.print("$$$$$$$$$$$$$$$ errorResponse $$$$$$$$ " + JSON.stringify(errorResponse));
            });
        }

        function errorCB(err) {
            kony.print("$$$$$$$$$$$ err  $$$$$$$$$ " + JSON.stringify(err));
        }
        kony.model.ApplicationContext.createModel("Restaurant", "FavouriteRestaurant", {
            "access": "online"
        }, {}, successCB, errorCB);
    },
    "locateRestaurant": function() {
        try {
            var navigateTofrmMap = new kony.mvc.Navigation("frmMap");
            navigateTofrmMap.navigate(this.restaurantObj);
        } catch (exp) {
            kony.print(JSON.stringify(exp));
        }
    },
    "navigateTofrmFavourite": function() {
        try {
            var navigateTofrmFavourite = new kony.mvc.Navigation("frmFavourite");
            navigateTofrmFavourite.navigate();
        } catch (exp) {
            kony.print(JSON.stringify(exp));
        }
    },
    "navigateTofrmRestaurants": function() {
        try {
            var navigateTofrmMap = new kony.mvc.Navigation("frmRestaurants");
            navigateTofrmMap.navigate();
        } catch (exp) {
            kony.print(JSON.stringify(exp));
        }
    },
    "getFavouriteRestaurant": function() {
        var params = {};
        params.queryParams = {
            device_id: kony.os.deviceInfo().id,
        };
        var navigateTofrmFavourite = new kony.mvc.Navigation("frmFavourite");
        var modelContext = new kony.model.ModelContext();
        modelContext.setRequestOptions("segRestaurant", params);
        navigateTofrmFavourite.setFormConfig(frmFavouriteConfig);
        navigateTofrmFavourite.setModelContext(modelContext);
        try {
            navigateTofrmFavourite.navigate();
        } catch (exp) {
            kony.print("Error in navigating the form");
        }
    },
    "AS_Button_35757ba08e0042db8e42402dc4f81253": function AS_Button_35757ba08e0042db8e42402dc4f81253(eventobject) {
        var self = this;
        this.getFavouriteRestaurant();
    },
    "AS_Button_ca05cd8f5cf545cfab4f3bc54b9ba5c4": function AS_Button_ca05cd8f5cf545cfab4f3bc54b9ba5c4(eventobject) {
        var self = this;
        this.navigateTofrmRestaurants();
    },
    "AS_Button_99cb95197af140b284b78f44dc2e6d1f": function AS_Button_99cb95197af140b284b78f44dc2e6d1f(eventobject) {
        var self = this;
        this.locateRestaurant();
    },
    "AS_Image_20209c86168d4b80be10829733e71b6f": function AS_Image_20209c86168d4b80be10829733e71b6f(eventobject, x, y) {
        var self = this;
        this.makeRestaurantFavourite();
    }
})