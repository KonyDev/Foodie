define({
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    AS_Button_e9d060fb41cf4ef5b9a3a90fe0f9d414: function AS_Button_e9d060fb41cf4ef5b9a3a90fe0f9d414(eventobject) {
        var self = this;
        this.getCity();
    },
    AS_ListBox_fdcc9057f78142ee947e602934d655d4: function AS_ListBox_fdcc9057f78142ee947e602934d655d4(eventobject) {
        var self = this;
        this.searchRestaurant();
    },
    AS_Segment_g76dab97ca944831b7f522f10cb7c4be: function AS_Segment_g76dab97ca944831b7f522f10cb7c4be(eventobject, sectionNumber, rowNumber) {
        var self = this;
        this.segOnRowClick();
    },
    AS_Segment_afa41cd7d6004aa5bd8c80fc46f6f50e: function AS_Segment_afa41cd7d6004aa5bd8c80fc46f6f50e(eventobject, sectionNumber, rowNumber) {
        var self = this;
        this.onMyRowClick();
    },
    AS_Button_a93614de9cbc4844909c2c7033b4404b: function AS_Button_a93614de9cbc4844909c2c7033b4404b(eventobject) {
        var self = this;
        this.getFavouriteRestaurant();
    },
    AS_Button_i7591569f6ce40c4a718993123479ab8: function AS_Button_i7591569f6ce40c4a718993123479ab8(eventobject) {
        var self = this;
        this.navigateTofrmHome();
    }
});