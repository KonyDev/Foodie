//Type your code here
// Sample code to register to messaging service
var messagingClient = null;

function subscribeForPushNotification(registrationId) {
    var UFID = kony.store.getItem("EMAIL");
    var client = kony.sdk.getCurrentInstance();
    var deviceId = kony.os.deviceInfo().deviceid;
    var osType;
    if (kony.os.deviceInfo().name === "android") {
        osType = "androidgcm";
    } else if (kony.os.deviceInfo().name === "iPhone") osType = "iphone";
    try {
        messagingClient = client.getMessagingService();
        messagingClient.register(osType, deviceId, registrationId, UFID, function(response) {
            kony.print("Subscription Success " + JSON.stringify(response));
        }, function(error) {
            kony.print("Subscription Failure " + JSON.stringify(error));
        });
    } catch (exception) {
        kony.print("Exception" + exception.message);
    }
}
// Sample code to unregister from messaging service
function unsubscribePushNotification() {
    messagingClient.unregister(function(response) {
        kony.print("Unregistration Success " + JSON.stringify(response));
    }, function(error) {
        kony.print("Unregistration Failure " + JSON.stringify(error));
    });
}