define({
    "restaurantList": [],
    "image_url": "",
    "onNavigate": function(param) {
        if (param === undefined || param === null) return;
        image_url = param;
    },
    "navigateToFormProfile": function() {
        try {
            var navigateObject = new kony.mvc.Navigation("frmProfile");
            this.hideMenu();
            navigateObject.navigate();
        } catch (exp) {
            kony.print(JSON.stringify(exp));
        }
    },
    "setGestureRecognizer": function() {
        var controllerScope = this;

        function swipeGestureHandler(commonWidget, gestureInfo, context) {
            kony.print("\n swipe performed\n");
            try {
                var direction = "";
                var GesType = "" + gestureInfo.gestureType;
                var animObj;
                if (GesType == constants.GESTURE_TYPE_SWIPE) {
                    var swipeDirection = "" + gestureInfo.swipeDirection; //Read swipe direction
                    if (swipeDirection == "1") {
                        controllerScope.hideMenu();
                    } else if (swipeDirection == "2") {
                        controllerScope.showMenu();
                    }
                }
            } catch (exp) {
                alert("error while performing animation" + JSON.stringify(exp));
            }
        }
        try {
            kony.print("$$$$$$$$$$$$$ in setGestureRecognizer $$$$$$$");
            this.view.addGestureRecognizer(constants.GESTURE_TYPE_SWIPE, {
                fingers: 1,
                swipedistance: 50,
                swipevelocity: 75
            }, swipeGestureHandler);
        } catch (err) {
            alert("error while regestering the gestures:" + err);
        }
    },
    "onMyRowClick": function() {
        var selectedRowIndex = this.view.segRestaurant.selectedRowIndex[1];
        try {
            var navigateTofrmDetails = new kony.mvc.Navigation("frmResDetails");
            var resObj = this.restaurantList[selectedRowIndex];
            navigateTofrmDetails.navigate(resObj);
        } catch (exp) {
            kony.print(JSON.stringify(exp));
        }
    },
    "onFetchData": function(sc, ec) {
        var myController = this;

        function success(data) {
            kony.print("in sc of frmRestaurant controller:" + JSON.stringify(data));
            myController.restaurantList = data._raw_response_.segRestaurant.records;
            sc(data);
        }

        function error(err) {
            kony.print("in error of frmRestaurant controller:" + JSON.stringify(err.getRootErrorObj()));
            ec(err);
        }
        kony.model.ApplicationContext.showLoadingScreen("Loading restaurants ...");
        this.fetchData(success.bind(this), error);
    },
    "searchRestaurant": function() {
        try {
            var navigateObj = new kony.mvc.Navigation("frmSearchRestaurant");
            this.hideMenu();
            navigateObj.navigate();
        } catch (exp) {
            kony.print(JSON.stringify(exp));
        }
    },
    "masterFunction": function() {
        this.view.MasterMenu.imgLogo.src = image_url;
        this.setGestureRecognizer();
    },
    "signOut": function() {
        try {
            var navigateObject = new kony.mvc.Navigation("frmBrowser");
            var data = {
                "provider": "GoogleOauth",
                "operation": "logOut"
            };
            navigateObject.navigate(data);
            this.hideMenu();
        } catch (exp) {
            kony.print(JSON.stringify(exp));
        }
    },
    "getFavouriteRestaurant": function() {
        this.hideMenu();
        var params = {};
        params.queryParams = {
            "$filter": "device_id eq " + "'" + kony.os.deviceInfo().deviceid + "'"
        };
        var navigateTofrmFavourite = new kony.mvc.Navigation("frmFavourite");
        var modelContext = new kony.model.ModelContext();
        modelContext.setRequestOptions("segRestaurant", params);
        navigateTofrmFavourite.setFormConfig(frmFavouriteConfig);
        navigateTofrmFavourite.setModelContext(modelContext);
        try {
            navigateTofrmFavourite.navigate();
        } catch (exp) {
            kony.print("Error in navigating the form");
        }
    },
    "hideMenu": function() {
        this.view.MasterMenu.animate(kony.ui.createAnimation({
            100: {
                left: "-100%",
                "stepConfig": {}
            }
        }), {
            delay: 0,
            fillMode: kony.anim.FILL_MODE_FORWARDS,
            duration: .40
        }, {
            animationEnd: function() {}
        });
    },
    "showMenu": function() {
        this.view.MasterMenu.animate(kony.ui.createAnimation({
            100: {
                left: "0%",
                "stepConfig": {}
            }
        }), {
            delay: 0,
            fillMode: kony.anim.FILL_MODE_FORWARDS,
            duration: .40
        }, {
            animationEnd: function() {}
        });
    },
    "AS_Image_a6d467ee5abc4a66b317ed6472c4a2c3": function AS_Image_a6d467ee5abc4a66b317ed6472c4a2c3(eventobject, x, y) {
        var self = this;
        this.showMenu();
    },
    "AS_Segment_5df59f9c2d334da3a72011f5ffb8520b": function AS_Segment_5df59f9c2d334da3a72011f5ffb8520b(eventobject, sectionNumber, rowNumber) {
        var self = this;
        this.onMyRowClick();
    },
    "AS_Button_f2b727fb77084e958bffbd1ea029e41f": function AS_Button_f2b727fb77084e958bffbd1ea029e41f(eventobject) {
        var self = this;
        this.navigateToFormProfile();
    },
    "AS_Button_f3fd38261ceb4883bf113ff8cd2d9c12": function AS_Button_f3fd38261ceb4883bf113ff8cd2d9c12(eventobject) {
        var self = this;
        this.hideMenu();
    },
    "AS_Button_80d8337ad975457784c8d6fd7a336e5d": function AS_Button_80d8337ad975457784c8d6fd7a336e5d(eventobject) {
        var self = this;
        this.getFavouriteRestaurant();
    },
    "AS_Button_3817c3dc2db44de8b512d1f9937df796": function AS_Button_3817c3dc2db44de8b512d1f9937df796(eventobject) {
        var self = this;
        this.pushRegistration();
    },
    "AS_Button_ab26757515d34db2a60f5ef2ffe46323": function AS_Button_ab26757515d34db2a60f5ef2ffe46323(eventobject) {
        var self = this;
        this.signOut();
    },
    "AS_FlexContainer_7127bf2110594b479dd57e62f7142247": function AS_FlexContainer_7127bf2110594b479dd57e62f7142247(eventobject) {
        var self = this;
        this.dummyFun();
    },
    "AS_Button_f5fe1698ed7047e6afea1840ce9fec6d": function AS_Button_f5fe1698ed7047e6afea1840ce9fec6d(eventobject) {
        var self = this;
        this.navigateToFormProfile();
    },
    "AS_Button_i3c3cf468a22422ebd0d80e36f1d4fc2": function AS_Button_i3c3cf468a22422ebd0d80e36f1d4fc2(eventobject) {
        var self = this;
        this.hideMenu();
    },
    "AS_Button_ef816ce4bbc449eb8ca143fd39785f0a": function AS_Button_ef816ce4bbc449eb8ca143fd39785f0a(eventobject) {
        var self = this;
        this.getFavouriteRestaurant();
    },
    "AS_Button_ae429e0ea0bd47dd9024f84bfb6fe0d1": function AS_Button_ae429e0ea0bd47dd9024f84bfb6fe0d1(eventobject) {
        var self = this;
        this.hideMenu();
        pushRegistration.call(this);
    },
    "AS_Button_ffffc62133ae4079af72c3f04b8ee88d": function AS_Button_ffffc62133ae4079af72c3f04b8ee88d(eventobject) {
        var self = this;
        this.signOut();
    },
    "AS_Button_i431988f31484251a9a9eba0f70a9b8c": function AS_Button_i431988f31484251a9a9eba0f70a9b8c(eventobject) {
        var self = this;
        this.searchRestaurant();
    },
    "AS_FlexContainer_bf1c5f2b09864185bd10b95fb07f94b2": function AS_FlexContainer_bf1c5f2b09864185bd10b95fb07f94b2(eventobject) {
        var self = this;
        self.AS_FlexContainer_e88fd6abbf1b49cdad910feff23d7328(eventobject);
    },
    "AS_FlexContainer_f17a97fea8304cd2a7ac3c0af75c83b9": function AS_FlexContainer_f17a97fea8304cd2a7ac3c0af75c83b9(eventobject) {
        var self = this;
        this.masterFunction();
    },
    "AS_Form_553c8effd5dd4e03b7bdf75b9c55a878": function AS_Form_553c8effd5dd4e03b7bdf75b9c55a878(eventobject) {
        var self = this;
        //this.setGestureRecognizer();
    },
    "AS_Form_i6e21e49ff9d4016899d76612923a348": function AS_Form_i6e21e49ff9d4016899d76612923a348(eventobject) {
        var self = this;
        return callbackAndroidSetCallbacks.call(this);
    },
    "AS_FlexContainer_e88fd6abbf1b49cdad910feff23d7328": function AS_FlexContainer_e88fd6abbf1b49cdad910feff23d7328(eventobject) {
        var self = this;
        return;
    }
})