define("flxRootContainer", function() {
    return function(controller) {
        var flxRootContainer = new kony.ui.FlexContainer({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "height": "70dp",
            "id": "flxRootContainer",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "skin": "CopyslFbox01adde275a1d34d"
        }, {}, {});
        flxRootContainer.setDefaultUnit(kony.flex.DP);
        var flxRestaurantInfo = new kony.ui.FlexContainer({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "height": "100%",
            "id": "flxRestaurantInfo",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "0dp",
            "skin": "sknFlxWhite",
            "top": "0dp",
            "width": "100%",
            "zIndex": 5
        }, {}, {});
        flxRestaurantInfo.setDefaultUnit(kony.flex.DP);
        var imgResIcon = new kony.ui.Image2({
            "centerY": "50%",
            "height": "80%",
            "id": "imgResIcon",
            "isVisible": true,
            "left": "0dp",
            "skin": "slImage",
            "src": "imagedrag.png",
            "width": "18%",
            "zIndex": 1
        }, {
            "imageScaleMode": constants.IMAGE_SCALE_MODE_FIT_TO_DIMENSIONS,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {});
        var flxTitle = new kony.ui.FlexContainer({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "height": "28dp",
            "id": "flxTitle",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "19%",
            "skin": "slFbox",
            "top": "0dp",
            "width": "81%",
            "zIndex": 1
        }, {}, {});
        flxTitle.setDefaultUnit(kony.flex.DP);
        var lblResName = new kony.ui.Label({
            "centerY": "50%",
            "height": "100%",
            "id": "lblResName",
            "isVisible": true,
            "left": "0dp",
            "skin": "CopyslLabel0649382ce57cb45",
            "text": "Restaurant name",
            "top": "0dp",
            "width": kony.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {
            "textCopyable": false,
            "wrapping": constants.WIDGET_TEXT_WORD_WRAP
        });
        var lblRating = new kony.ui.Label({
            "centerY": "50%",
            "height": "90%",
            "id": "lblRating",
            "isVisible": true,
            "right": "10dp",
            "skin": "sknLblRating",
            "text": "4.5",
            "width": kony.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_CENTER,
            "padding": [1, 0, 1, 0],
            "paddingInPixel": false
        }, {
            "textCopyable": false,
            "wrapping": constants.WIDGET_TEXT_WORD_WRAP
        });
        flxTitle.add(lblResName, lblRating);
        var lblCuisines = new kony.ui.Label({
            "height": "30dp",
            "id": "lblCuisines",
            "isVisible": true,
            "left": "19%",
            "skin": "sknLblTitle2",
            "text": "Cuisines",
            "top": "28dp",
            "width": kony.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {
            "textCopyable": false,
            "wrapping": constants.WIDGET_TEXT_WORD_WRAP
        });
        flxRestaurantInfo.add(imgResIcon, flxTitle, lblCuisines);
        var flxDeleteRestaurant = new kony.ui.FlexContainer({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "height": "100%",
            "id": "flxDeleteRestaurant",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "0dp",
            "skin": "slFbox",
            "top": "0dp",
            "width": "100%",
            "zIndex": 1
        }, {}, {});
        flxDeleteRestaurant.setDefaultUnit(kony.flex.DP);
        var flxDelete = new kony.ui.FlexContainer({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "height": "100%",
            "id": "flxDelete",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "right": "0dp",
            "skin": "CopyslFbox03d7f915c192248",
            "top": "0dp",
            "width": "70dp",
            "zIndex": 1
        }, {}, {});
        flxDelete.setDefaultUnit(kony.flex.DP);
        var imgDelete = new kony.ui.Image2({
            "centerX": "50%",
            "centerY": "50%",
            "id": "imgDelete",
            "isVisible": true,
            "left": "0dp",
            "skin": "slImage",
            "src": "delete.png",
            "top": "0dp",
            "width": kony.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, {
            "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {});
        flxDelete.add(imgDelete);
        flxDeleteRestaurant.add(flxDelete);
        var lblLine = new kony.ui.Label({
            "bottom": "1dp",
            "height": "1dp",
            "id": "lblLine",
            "isVisible": true,
            "left": "3%",
            "skin": "sknLblLine",
            "width": "95%",
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {
            "textCopyable": false,
            "wrapping": constants.WIDGET_TEXT_WORD_WRAP
        });
        flxRootContainer.add(flxRestaurantInfo, flxDeleteRestaurant, lblLine);
        return flxRootContainer;
    }
})