define({
    "onNavigate": function() {
        this.view.imgProfile.src = kony.store.getItem("IMAGE_URL");
        this.view.txtBoxFname.text = kony.store.getItem("FNAME");
        this.view.txtBoxLname.text = kony.store.getItem("LNAME");
        this.view.txtBoxEmail.text = kony.store.getItem("EMAIL");
        this.view.txtBoxMob.text = kony.store.getItem("MOB");
    },
    "navigateToFormHome": function() {
        try {
            var navigateObject = new kony.mvc.Navigation("frmRestaurants");
            navigateObject.navigate();
        } catch (exp) {
            kony.print(JSON.stringify(exp));
        }
    },
    "updateDetails": function() {
        var controllerScope = this;
        var user = {};
        user["email"] = this.view.txtBoxEmail.text;
        user["firstName"] = this.view.txtBoxFname.text;
        user["imageUrl"] = this.view.imgProfile.src;
        user["lastName"] = this.view.txtBoxLname.text;
        user["device_id"] = kony.os.deviceInfo().deviceid;
        user["mob"] = this.view.txtBoxMob.text;

        function successCB(dataModel) {
            var userDataObject = new kony.sdk.dto.DataObject("User");
            userDataObject.setRecord(user);
            dataModel.update({
                dataObject: userDataObject
            }, function(successResponse) {
                kony.print("$$$$$$$$ user update success $$$$$$$" + JSON.stringify(successResponse));
                alert("update success!");
            }, function(errorResponse) {
                kony.print("$$$$$$$$$$$$$$$ user updation failed $$$$$$$$ " + JSON.stringify(errorResponse));
                alert("Something went wrong,please try later");
            });
        }

        function errorCB(err) {
            kony.print("$$$$$$$$$$$ err  $$$$$$$$$ " + JSON.stringify(err));
        }
        try {
            kony.model.ApplicationContext.createModel("User", "Profile", {
                "access": "online"
            }, {}, successCB, errorCB);
        } catch (exp) {
            kony.print("Exception while creating data model");
        }
    },
    "AS_Button_6059884174c64c95a2df0c2d1492e4ca": function AS_Button_6059884174c64c95a2df0c2d1492e4ca(eventobject) {
        var self = this;
        this.navigateToFormHome();
    },
    "AS_Button_ca5df96be4ce4ca0a45a350f09e789d3": function AS_Button_ca5df96be4ce4ca0a45a350f09e789d3(eventobject) {
        var self = this;
        this.updateDetails();
    }
})