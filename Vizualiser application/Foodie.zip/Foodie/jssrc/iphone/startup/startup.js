//startup.js file
var globalhttpheaders = {};
var appConfig = {
    appId: "Foodie",
    appName: "Foodie",
    appVersion: "1.0.0",
    platformVersion: null,
    serverIp: "10.10.17.181",
    serverPort: "80",
    secureServerPort: "443",
    isDebug: true,
    middlewareContext: "Foodie",
    isturlbase: "http://KH1495.kitspl.com:8080/services",
    isMFApp: true,
    appKey: "d2744b6c3e6fa897b21ca9b467a4ba53",
    appSecret: "510366f1c5eaf7bd5f702966636e9ae0",
    serviceUrl: "http://KH1495.kitspl.com:8080/authService/100000002/appconfig",
    svcDoc: {
        "appId": "b1fe40f2-3170-4dcf-ba4f-9c032047cf73",
        "baseId": "19a26a5d-be4c-40b1-9e55-73874137bc4e",
        "name": "Foodie",
        "selflink": "http://KH1495.kitspl.com:8080/authService/100000002/appconfig",
        "login": [{
            "type": "oauth2",
            "prov": "GoogleOauth",
            "url": "http://KH1495.kitspl.com:8080/authService/100000002",
            "alias": "GoogleOauth"
        }],
        "messagingsvc": {
            "appId": "b1fe40f2-3170-4dcf-ba4f-9c032047cf73",
            "url": "http://KH1495.kitspl.com:8080/kpns/api/v1"
        },
        "integsvc": {
            "Restauants": "http://KH1495.kitspl.com:8080/services/Restauants"
        },
        "reportingsvc": {
            "custom": "http://KH1495.kitspl.com:8080/services/CMS",
            "session": "http://KH1495.kitspl.com:8080/services/IST"
        },
        "services_meta": {
            "Restauants": {
                "version": "1.0",
                "url": "http://KH1495.kitspl.com:8080/services/Restauants",
                "type": "integsvc"
            },
            "Profile": {
                "version": "1.0",
                "url": "http://KH1495.kitspl.com:8080/services/data/v1/Profile",
                "metadata_url": "http://KH1495.kitspl.com:8080/services/metadata/v1/Profile",
                "type": "objectsvc"
            },
            "NearByRestaurant": {
                "version": "1.0",
                "url": "http://KH1495.kitspl.com:8080/services/data/v1/NearByRestaurant",
                "metadata_url": "http://KH1495.kitspl.com:8080/services/metadata/v1/NearByRestaurant",
                "type": "objectsvc"
            },
            "RestaurantDetails": {
                "version": "1.0",
                "url": "http://KH1495.kitspl.com:8080/services/data/v1/RestaurantDetails",
                "metadata_url": "http://KH1495.kitspl.com:8080/services/metadata/v1/RestaurantDetails",
                "type": "objectsvc"
            },
            "FavouriteRestaurant": {
                "version": "1.0",
                "url": "http://KH1495.kitspl.com:8080/services/data/v1/FavouriteRestaurant",
                "metadata_url": "http://KH1495.kitspl.com:8080/services/metadata/v1/FavouriteRestaurant",
                "type": "objectsvc"
            }
        }
    },
    svcDocRefresh: false,
    svcDocRefreshTimeSecs: -1,
    eventTypes: ["FormEntry", "ServiceRequest", "Error", "Crash"],
    url: "http://KH1495.kitspl.com:8080/Foodie/MWServlet",
    secureurl: "http://KH1495.kitspl.com:8080/Foodie/MWServlet"
};
sessionID = "";

function appInit(params) {
    skinsInit();
    kony.application.setCheckBoxSelectionImageAlignment(constants.CHECKBOX_SELECTION_IMAGE_ALIGNMENT_RIGHT);
    kony.application.setDefaultTextboxPadding(false);
    kony.application.setRespectImageSizeForImageWidgetAlignment(true);
    setAppBehaviors();
};

function setAppBehaviors() {
    kony.application.setApplicationBehaviors({
        applyMarginPaddingInBCGMode: false,
        adherePercentageStrictly: true,
        retainSpaceOnHide: true,
        isMVC: true,
        marginsIncludedInWidgetContainerWeight: true,
        APILevel: 7200
    })
};

function themeCallBack() {
    callAppMenu();
    initializeGlobalVariables();
    applicationController = require("applicationController");
    kony.application.setApplicationInitializationEvents({
        init: applicationController.appInit,
        postappinit: applicationController.AS_AppEvents_g103c2f746c847119b9390c18bd95d15,
        showstartupform: function() {
            var startForm = new kony.mvc.Navigation("frmLogin");
            startForm.navigate();
        }
    });
};

function loadResources() {
    globalhttpheaders = {};
    sdkInitConfig = {
        "appConfig": appConfig,
        "isMFApp": appConfig.isMFApp,
        "appKey": appConfig.appKey,
        "appSecret": appConfig.appSecret,
        "eventTypes": appConfig.eventTypes,
        "serviceUrl": appConfig.serviceUrl
    }
    kony.setupsdks(sdkInitConfig, onSuccessSDKCallBack, onSuccessSDKCallBack);
};

function onSuccessSDKCallBack() {
    kony.theme.setCurrentTheme("default", themeCallBack, themeCallBack);
}
kony.application.setApplicationMode(constants.APPLICATION_MODE_NATIVE);
//If default locale is specified. This is set even before any other app life cycle event is called.
loadResources();
// If you wish to debug Application Initialization events, now is the time to
// place breakpoints.
debugger;