define("frmRestaurants", function() {
    return function(controller) {
        function addWidgetsfrmRestaurants() {
            this.setDefaultUnit(kony.flex.DP);
            var flxRoot = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxRoot",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 2
            }, {}, {});
            flxRoot.setDefaultUnit(kony.flex.DP);
            var flxTitle = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "9%",
                "id": "flxTitle",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 2
            }, {}, {});
            flxTitle.setDefaultUnit(kony.flex.DP);
            var lblztitle = new kony.ui.Label({
                "centerX": "50%",
                "centerY": "50%",
                "id": "lblztitle",
                "isVisible": true,
                "skin": "sknLblTitle2",
                "text": "Restaurant",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "textCopyable": false,
                "wrapping": constants.WIDGET_TEXT_WORD_WRAP
            });
            var Image035df76ac71f048 = new kony.ui.Image2({
                "centerY": "50%",
                "height": "30dp",
                "id": "Image035df76ac71f048",
                "isVisible": true,
                "left": "10dp",
                "onTouchEnd": controller.AS_Image_f6fd8ab84b3345dba6185ea77fe209b8,
                "skin": "slImage",
                "src": "burger.png",
                "top": "0dp",
                "width": "30dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxTitle.add(lblztitle, Image035df76ac71f048);
            var flxRootContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "91%",
                "id": "flxRootContainer",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "skin": "slFbox",
                "top": "9%",
                "width": "100%",
                "zIndex": 1
            }, {}, {});
            flxRootContainer.setDefaultUnit(kony.flex.DP);
            var segRestaurant = new kony.ui.SegmentedUI2({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "data": [{
                    "imgDelete": "imagedrag.png",
                    "imgResIcon": "imagedrag.png",
                    "lblCuisines": "Cuisines",
                    "lblLine": "Label",
                    "lblRating": "Rating",
                    "lblResName": "Restaurant name"
                }, {
                    "imgDelete": "imagedrag.png",
                    "imgResIcon": "imagedrag.png",
                    "lblCuisines": "Cuisines",
                    "lblLine": "Label",
                    "lblRating": "Rating",
                    "lblResName": "Restaurant name"
                }, {
                    "imgDelete": "imagedrag.png",
                    "imgResIcon": "imagedrag.png",
                    "lblCuisines": "Cuisines",
                    "lblLine": "Label",
                    "lblRating": "Rating",
                    "lblResName": "Restaurant name"
                }],
                "groupCells": false,
                "height": "100%",
                "id": "segRestaurant",
                "isVisible": true,
                "left": "0dp",
                "needPageIndicator": true,
                "onRowClick": controller.AS_Segment_5df59f9c2d334da3a72011f5ffb8520b,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowFocusSkin": "Copyseg0ad33c17cd47345",
                "rowSkin": "Copyseg0ad33c17cd47345",
                "rowTemplate": "flxRootContainer",
                "scrollingEvents": {},
                "sectionHeaderSkin": "sliPhoneSegmentHeader",
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorRequired": false,
                "showScrollbars": false,
                "top": "0dp",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {
                    "flxDelete": "flxDelete",
                    "flxDeleteRestaurant": "flxDeleteRestaurant",
                    "flxRestaurantInfo": "flxRestaurantInfo",
                    "flxRootContainer": "flxRootContainer",
                    "flxTitle": "flxTitle",
                    "imgDelete": "imgDelete",
                    "imgResIcon": "imgResIcon",
                    "lblCuisines": "lblCuisines",
                    "lblLine": "lblLine",
                    "lblRating": "lblRating",
                    "lblResName": "lblResName"
                },
                "width": "100%",
                "zIndex": 1
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "bounces": true,
                "editStyle": constants.SEGUI_EDITING_STYLE_NONE,
                "enableDictionary": false,
                "indicator": constants.SEGUI_ROW_SELECT,
                "progressIndicatorColor": constants.PROGRESS_INDICATOR_COLOR_WHITE,
                "showProgressIndicator": true
            });
            flxRootContainer.add(segRestaurant);
            var flxMenuContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxMenuContainer",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0%",
                "onClick": controller.AS_FlexContainer_7127bf2110594b479dd57e62f7142247,
                "skin": "sknFlxGrey",
                "top": "0dp",
                "width": "100%",
                "zIndex": 20
            }, {}, {});
            flxMenuContainer.setDefaultUnit(kony.flex.DP);
            var flxMenuRoot = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxMenuRoot",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "skin": "sknFlxDarkGrey",
                "top": "0dp",
                "width": "70%",
                "zIndex": 1
            }, {}, {});
            flxMenuRoot.setDefaultUnit(kony.flex.DP);
            var flxProfile = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "180dp",
                "id": "flxProfile",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {}, {});
            flxProfile.setDefaultUnit(kony.flex.DP);
            var imgLogo = new kony.ui.Image2({
                "centerX": "50%",
                "centerY": "50%",
                "height": "100%",
                "id": "imgLogo",
                "isVisible": true,
                "skin": "slImage",
                "src": "imagedrag.png",
                "width": "100%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxProfile.add(imgLogo);
            var lblLine = new kony.ui.Label({
                "centerX": "50%",
                "height": "3dp",
                "id": "lblLine",
                "isVisible": true,
                "left": "0",
                "skin": "sknLblLine",
                "top": "0",
                "width": "90%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "textCopyable": false,
                "wrapping": constants.WIDGET_TEXT_WORD_WRAP
            });
            var btnProfile = new kony.ui.Button({
                "centerX": "50%",
                "focusSkin": "slButtonGlossRed",
                "height": "50dp",
                "id": "btnProfile",
                "isVisible": true,
                "left": "0dp",
                "onClick": controller.AS_Button_f2b727fb77084e958bffbd1ea029e41f,
                "skin": "sknBtnMenu",
                "text": "profile",
                "width": "260dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "showProgressIndicator": true
            });
            var lblLine2 = new kony.ui.Label({
                "centerX": "50%",
                "height": "3dp",
                "id": "lblLine2",
                "isVisible": true,
                "left": "0",
                "skin": "sknLblLine",
                "top": "0",
                "width": "90%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "textCopyable": false,
                "wrapping": constants.WIDGET_TEXT_WORD_WRAP
            });
            var btnNearByRestaurant = new kony.ui.Button({
                "centerX": "50%",
                "focusSkin": "slButtonGlossRed",
                "height": "50dp",
                "id": "btnNearByRestaurant",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknBtnMenu",
                "text": "near by restaurant",
                "top": "0",
                "width": "260dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "showProgressIndicator": true
            });
            var lblLine3 = new kony.ui.Label({
                "centerX": "50%",
                "height": "3dp",
                "id": "lblLine3",
                "isVisible": true,
                "left": "0",
                "skin": "sknLblLine",
                "top": "0",
                "width": "90%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "textCopyable": false,
                "wrapping": constants.WIDGET_TEXT_WORD_WRAP
            });
            var btnFavourite = new kony.ui.Button({
                "centerX": "50%",
                "focusSkin": "sknBtnFavourite",
                "height": "50dp",
                "id": "btnFavourite",
                "isVisible": true,
                "left": "0dp",
                "onClick": controller.AS_Button_80d8337ad975457784c8d6fd7a336e5d,
                "skin": "sknBtnTrans",
                "text": "Favourite",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "showProgressIndicator": true
            });
            var lblLne4 = new kony.ui.Label({
                "centerX": "50%",
                "height": "3dp",
                "id": "lblLne4",
                "isVisible": true,
                "left": "0",
                "skin": "sknLblLine",
                "top": "0",
                "width": "90%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "textCopyable": false,
                "wrapping": constants.WIDGET_TEXT_WORD_WRAP
            });
            var btnSubscribe = new kony.ui.Button({
                "centerX": "50%",
                "focusSkin": "slButtonGlossRed",
                "height": "50dp",
                "id": "btnSubscribe",
                "isVisible": true,
                "left": "0dp",
                "onClick": controller.AS_Button_3817c3dc2db44de8b512d1f9937df796,
                "skin": "sknBtnMenu",
                "text": "subscribe",
                "top": "0",
                "width": "260dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "showProgressIndicator": true
            });
            var lblLine5 = new kony.ui.Label({
                "centerX": "50%",
                "height": "3dp",
                "id": "lblLine5",
                "isVisible": true,
                "left": "0",
                "skin": "sknLblLine",
                "top": "0",
                "width": "90%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "textCopyable": false,
                "wrapping": constants.WIDGET_TEXT_WORD_WRAP
            });
            var btnSignOut = new kony.ui.Button({
                "centerX": "50%",
                "focusSkin": "slButtonGlossRed",
                "height": "50dp",
                "id": "btnSignOut",
                "isVisible": true,
                "onClick": controller.AS_Button_ab26757515d34db2a60f5ef2ffe46323,
                "skin": "sknBtnTrans",
                "text": "Sign Out",
                "top": "0dp",
                "width": "260dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "showProgressIndicator": true
            });
            flxMenuRoot.add(flxProfile, lblLine, btnProfile, lblLine2, btnNearByRestaurant, lblLine3, btnFavourite, lblLne4, btnSubscribe, lblLine5, btnSignOut);
            var flxShadow = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxShadow",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "skin": "sknFlxGrey",
                "top": "0dp",
                "width": "30%",
                "zIndex": 1
            }, {}, {});
            flxShadow.setDefaultUnit(kony.flex.DP);
            flxShadow.add();
            flxMenuContainer.add(flxMenuRoot, flxShadow);
            flxRoot.add(flxTitle, flxRootContainer, flxMenuContainer);
            this.add(flxRoot);
        };
        return [{
            "addWidgets": addWidgetsfrmRestaurants,
            "enabledForIdleTimeout": false,
            "id": "frmRestaurants",
            "init": controller.AS_Form_553c8effd5dd4e03b7bdf75b9c55a878,
            "layoutType": kony.flex.FREE_FORM,
            "needAppMenu": false,
            "skin": "sknFrmGrey",
            "title": "Restaurants",
            "info": {
                "kuid": "9b74c11daa304d118f07a119e787eb8b"
            }
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": kony.flex.FREE_FORM,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {
            "configureExtendBottom": false,
            "configureExtendTop": false,
            "configureStatusBarStyle": false,
            "footerOverlap": false,
            "formTransparencyDuringPostShow": "100",
            "headerOverlap": false,
            "inputAccessoryViewType": constants.FORM_INPUTACCESSORYVIEW_CANCEL,
            "needsIndicatorDuringPostShow": false,
            "retainScrollPosition": false,
            "titleBar": false,
            "titleBarSkin": "sknLblFrmTitle"
        }]
    }
});