define({
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    AS_Button_1e3ede0adef04a10ad544461c4d00d3b: function AS_Button_1e3ede0adef04a10ad544461c4d00d3b(eventobject) {
        var self = this;
        this.navigateToFormEditProfile();
    },
    AS_Button_6931871508be4397860d409f4d9cf8b3: function AS_Button_6931871508be4397860d409f4d9cf8b3(eventobject) {
        var self = this;
        this.navigateToFormHome();
    }
});