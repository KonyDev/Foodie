define({
    "testMethod": function() {
        alert("from map template");
    },
    "getDirection": function(context) {
        this.executeOnParent("getDirection", context);
    },
    "AS_FlexContainer_2661e555919d430cb950404c7f89eca6": function AS_FlexContainer_2661e555919d430cb950404c7f89eca6(eventobject) {
        var self = this;
        this.testMethod();
    }
})