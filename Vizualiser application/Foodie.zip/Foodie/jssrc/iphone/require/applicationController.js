define({
    AS_AppEvents_g103c2f746c847119b9390c18bd95d15: function AS_AppEvents_g103c2f746c847119b9390c18bd95d15(eventobject) {
        var self = this;
        return callbackAndroidSetCallbacks.call(this);
    },
    appInit: function(params) {
        skinsInit();
        kony.mvc.registry.add("CopyFBox06e2541c111b848", "CopyFBox06e2541c111b848", "CopyFBox06e2541c111b848Controller");
        kony.mvc.registry.add("CopyFBox08c606abedf334f", "CopyFBox08c606abedf334f", "CopyFBox08c606abedf334fController");
        kony.mvc.registry.add("FBox0da8ea37aaf534e", "FBox0da8ea37aaf534e", "FBox0da8ea37aaf534eController");
        kony.mvc.registry.add("flxFavRootContainer", "flxFavRootContainer", "CopyflxRootContainer092b9168c7ab84fController");
        kony.mvc.registry.add("flxRootContainer", "flxRootContainer", "FlexContainer0188959058fb043Controller");
        kony.mvc.registry.add("flxMapTmpRootContiner", "flxMapTmpRootContiner", "FlexContainer0a038f14ef33446Controller");
        kony.mvc.registry.add("frmBrowser", "frmBrowser", "frmBrowserController");
        kony.mvc.registry.add("frmEditProfile", "frmEditProfile", "frmEditProfileController");
        kony.mvc.registry.add("frmFavourite", "frmFavourite", "frmFavouriteController");
        kony.mvc.registry.add("frmHome", "frmHome", "frmHomeController");
        kony.mvc.registry.add("frmLogin", "frmLogin", "frmLoginController");
        kony.mvc.registry.add("frmMap", "frmMap", "frmMapController");
        kony.mvc.registry.add("frmProfile", "frmProfile", "frmProfileController");
        kony.mvc.registry.add("frmResDetails", "frmResDetails", "frmResDetailsController");
        kony.mvc.registry.add("frmRestaurantBrowser", "frmRestaurantBrowser", "frmRestaurantBrowserController");
        kony.mvc.registry.add("frmRestaurants", "frmRestaurants", "frmRestaurantsController");
        kony.application.setCheckBoxSelectionImageAlignment(constants.CHECKBOX_SELECTION_IMAGE_ALIGNMENT_RIGHT);
        kony.application.setDefaultTextboxPadding(false);
        kony.application.setRespectImageSizeForImageWidgetAlignment(true);
        setAppBehaviors();
        if (typeof startBackgroundWorker != "undefined") {
            startBackgroundWorker();
        }
    },
    postAppInitCallBack: function() {
        return AS_AppEvents_g103c2f746c847119b9390c18bd95d15();
    }
});