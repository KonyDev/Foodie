//startup.js file
var globalhttpheaders = {};
var appConfig = {
    appId: "Foodie",
    appName: "Foodie",
    appVersion: "1.0.0",
    platformVersion: null,
    serverIp: "10.10.17.181",
    serverPort: "80",
    secureServerPort: "443",
    isDebug: true,
    middlewareContext: "Foodie",
    isturlbase: "https://sampletestcloud.qa-konycloud.com/services",
    isMFApp: true,
    appKey: "9fed0c9976855816e84b1dc9584570f2",
    appSecret: "974c93f4e7b805e99ed2f1984496f3",
    serviceUrl: "https://100000347.auth.qa-konycloud.com/appconfig",
    svcDoc: {
        "appId": "5d82cdb0-018c-4d30-9f72-31ead8a2c033",
        "baseId": "5e64eb17-31c7-4ae5-9193-29e1172092b2",
        "name": "Foodie",
        "selflink": "https://100000347.auth.qa-konycloud.com/appconfig",
        "login": [{
            "type": "oauth2",
            "prov": "ZGoogleOAuthv2",
            "url": "https://100000347.auth.qa-konycloud.com",
            "alias": "ZGoogleOAuthv2"
        }],
        "messagingsvc": {
            "appId": "5d82cdb0-018c-4d30-9f72-31ead8a2c033",
            "url": "https://sampletestcloud.messaging.qa-konycloud.com/api/v1"
        },
        "integsvc": {
            "Restauants": "https://sampletestcloud.qa-konycloud.com/services/Restauants"
        },
        "reportingsvc": {
            "custom": "https://sampletestcloud.qa-konycloud.com/services/CMS",
            "session": "https://sampletestcloud.qa-konycloud.com/services/IST"
        },
        "services_meta": {
            "Restauants": {
                "version": "1.0",
                "url": "https://sampletestcloud.qa-konycloud.com/services/Restauants",
                "type": "integsvc"
            },
            "Profile": {
                "version": "1.0",
                "url": "https://sampletestcloud.qa-konycloud.com/services/data/v1/Profile",
                "metadata_url": "https://sampletestcloud.qa-konycloud.com/services/metadata/v1/Profile",
                "type": "objectsvc"
            },
            "NearByRestaurant": {
                "version": "1.0",
                "url": "https://sampletestcloud.qa-konycloud.com/services/data/v1/NearByRestaurant",
                "metadata_url": "https://sampletestcloud.qa-konycloud.com/services/metadata/v1/NearByRestaurant",
                "type": "objectsvc"
            },
            "RestaurantDetails": {
                "version": "1.0",
                "url": "https://sampletestcloud.qa-konycloud.com/services/data/v1/RestaurantDetails",
                "metadata_url": "https://sampletestcloud.qa-konycloud.com/services/metadata/v1/RestaurantDetails",
                "type": "objectsvc"
            },
            "FavouriteRestaurant": {
                "version": "1.0",
                "url": "https://sampletestcloud.qa-konycloud.com/services/data/v1/FavouriteRestaurant",
                "metadata_url": "https://sampletestcloud.qa-konycloud.com/services/metadata/v1/FavouriteRestaurant",
                "type": "objectsvc"
            }
        }
    },
    svcDocRefresh: false,
    svcDocRefreshTimeSecs: -1,
    eventTypes: ["FormEntry", "ServiceRequest", "Error", "Crash"],
    url: "https://sampletestcloud.qa-konycloud.com/Foodie/MWServlet",
    secureurl: "https://sampletestcloud.qa-konycloud.com/Foodie/MWServlet"
};
sessionID = "";

function appInit(params) {
    skinsInit();
    setAppBehaviors();
};

function setAppBehaviors() {
    kony.application.setApplicationBehaviors({
        applyMarginPaddingInBCGMode: false,
        adherePercentageStrictly: true,
        retainSpaceOnHide: true,
        isMVC: true,
        marginsIncludedInWidgetContainerWeight: true,
        APILevel: 7200
    })
};

function themeCallBack() {
    initializeGlobalVariables();
    applicationController = require("applicationController");
    callAppMenu();
    kony.application.setApplicationInitializationEvents({
        init: applicationController.appInit,
        postappinit: applicationController.AS_AppEvents_j3fdee38f72542aaaf876abfc82dc2e8,
        showstartupform: function() {
            var startForm = new kony.mvc.Navigation("frmLogin");
            startForm.navigate();
        }
    });
};

function loadResources() {
    globalhttpheaders = {};
    sdkInitConfig = {
        "appConfig": appConfig,
        "isMFApp": appConfig.isMFApp,
        "appKey": appConfig.appKey,
        "appSecret": appConfig.appSecret,
        "eventTypes": appConfig.eventTypes,
        "serviceUrl": appConfig.serviceUrl
    }
    kony.setupsdks(sdkInitConfig, onSuccessSDKCallBack, onSuccessSDKCallBack);
};

function onSuccessSDKCallBack() {
    kony.theme.setCurrentTheme("default", themeCallBack, themeCallBack);
}
kony.application.setApplicationMode(constants.APPLICATION_MODE_NATIVE);
//If default locale is specified. This is set even before any other app life cycle event is called.
loadResources();
// If you wish to debug Application Initialization events, now is the time to
// place breakpoints.
debugger;