define({ 
 navigateTofrmHome: function() {
        try {
            var navigateObj = new kony.mvc.Navigation("frmHome");
            navigateObj.navigate();
        } catch (exp) {
            kony.print(JSON.stringify(exp));
        }
    },
 //Type your controller code here 
  onNavigate:function(restaurantObj){
    if(restaurantObj===null || restaurantObj=== undefined ) 
      return;
    this.resObj=restaurantObj;
    var order_url=restaurantObj["order_url"];
    this.view.browser.requestURLConfig={"URL":order_url};
  },
  makePayment:function(){
    try {
      var navigateObj = new kony.mvc.Navigation("frmPayment");
      navigateObj.navigate();
    }catch (exp) {
     kony.print(JSON.stringify(exp));
    }
  }

 });