define("flxMapTmpRootContiner", function() {
    return function(controller) {
        var flxMapTmpRootContiner = new kony.ui.FlexContainer({
            "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
            "clipBounds": true,
            "id": "flxMapTmpRootContiner",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "onClick": controller.AS_FlexContainer_2661e555919d430cb950404c7f89eca6,
            "skin": "CopyslFbox023616774fbc44b",
            "width": "80%"
        }, {}, {});
        flxMapTmpRootContiner.setDefaultUnit(kony.flex.DP);
        var lblName = new kony.ui.Label({
            "height": "30dp",
            "id": "lblName",
            "isVisible": true,
            "left": "55dp",
            "skin": "sknLblBlue",
            "text": "Name",
            "top": "5dp",
            "width": kony.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {
            "textCopyable": false,
            "wrapping": constants.WIDGET_TEXT_WORD_WRAP
        });
        var btnMapTemplate = new kony.ui.Button({
            "centerX": "50%",
            "focusSkin": "slButtonGlossRed",
            "height": "50dp",
            "id": "btnMapTemplate",
            "isVisible": true,
            "left": "60dp",
            "skin": "CopyslButtonGlossBlue0248a7cd81d514f",
            "text": "get direction",
            "top": "95dp",
            "width": "80%",
            "zIndex": 10
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_CENTER,
            "displayText": true,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {
            "showProgressIndicator": true
        });
        var lblRating = new kony.ui.Label({
            "id": "lblRating",
            "isVisible": true,
            "right": "15dp",
            "skin": "sknLblRating",
            "text": "5",
            "top": "5dp",
            "width": kony.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {
            "textCopyable": false,
            "wrapping": constants.WIDGET_TEXT_WORD_WRAP
        });
        var lblLine = new kony.ui.Label({
            "height": "2dp",
            "id": "lblLine",
            "isVisible": true,
            "left": "55dp",
            "skin": "sknLblLine",
            "top": "35dp",
            "width": "95%",
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {
            "textCopyable": false,
            "wrapping": constants.WIDGET_TEXT_WORD_WRAP
        });
        var lblCusines = new kony.ui.Label({
            "id": "lblCusines",
            "isVisible": true,
            "left": "55dp",
            "skin": "sknLblCuisines",
            "text": "Cuisines",
            "top": "37dp",
            "width": kony.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {
            "textCopyable": false,
            "wrapping": constants.WIDGET_TEXT_WORD_WRAP
        });
        var lblLine2 = new kony.ui.Label({
            "height": "3dp",
            "id": "lblLine2",
            "isVisible": true,
            "left": "5dp",
            "skin": "sknLblLine",
            "top": "67dp",
            "width": "95%",
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {
            "textCopyable": false,
            "wrapping": constants.WIDGET_TEXT_WORD_WRAP
        });
        var imgIcon = new kony.ui.Image2({
            "height": "50dp",
            "id": "imgIcon",
            "isVisible": true,
            "left": "5dp",
            "skin": "slImage",
            "src": "imagedrag.png",
            "top": "5dp",
            "width": "50dp",
            "zIndex": 1
        }, {
            "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {});
        flxMapTmpRootContiner.add(lblName, btnMapTemplate, lblRating, lblLine, lblCusines, lblLine2, imgIcon);
        return flxMapTmpRootContiner;
    }
})