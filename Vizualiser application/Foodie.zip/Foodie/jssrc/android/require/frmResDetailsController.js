define({
    "restaurantObj": {},
    "showRestaurantMenu": function() {
        try {
            var navigateObj = new kony.mvc.Navigation("frmRestaurantMenu");
            navigateObj.navigate(this.restaurantObj);
        } catch (exp) {
            kony.print(JSON.stringify(exp));
        }
    },
    "onNavigate": function(restaurantParameter) {
        var restaurant;
        if (restaurantParameter !== undefined) {
            this.restaurantObj = restaurantParameter;
            restaurant = restaurantParameter;
        } else {
            restaurant = this.restaurantObj;
        }
        kony.print("in the onNavigate of frmResDetails :" + JSON.stringify(restaurant));
        this.view.imgResIcon.src = restaurant["featured_image"];
        if (restaurant["user_rating"].length !== undefined) {
            this.view.lblRating.text = restaurant["user_rating"][0]["aggregate_rating"];
            this.view.lblUserRating.text = restaurant["user_rating"][0]["rating_text"];
            this.view.lblVotes.text = restaurant["user_rating"][0]["votes"];
        } else {
            this.view.lblRating.text = restaurant["user_rating"]["aggregate_rating"];
            this.view.lblUserRating.text = restaurant["user_rating"]["rating_text"];
            this.view.lblVotes.text = restaurant["user_rating"]["votes"];
        }
        this.view.lblName.text = restaurant["name"];
        this.view.lblCusines.text = restaurant["cuisines"];
        if (restaurant["locationObj"] !== undefined) {
            this.view.lblAddress.text = restaurant["locationObj"][0]["address111"];
        } else {
            this.view.lblAddress.text = restaurant["location"]["address111"];
        }
        this.view.lblCost.text = restaurant["currency"] + " " + restaurant["average_cost_for_two"] + " for 2 people.";
    },
    "makeRestaurantFavourite": function() {
        var controllerScope = this;

        function successCB(dataModel) {
            var resDataObject = new kony.sdk.dto.DataObject("Restaurant");
            var restaurant = {};
            restaurant["aggregate_rating"] = controllerScope.restaurantObj["user_rating"][0]["aggregate_rating"];
            restaurant["cuisines"] = controllerScope.restaurantObj["cuisines"];
            restaurant["device_id"] = kony.os.deviceInfo().deviceid;
            restaurant["name"] = controllerScope.restaurantObj["name"];
            restaurant["restaurant_id"] = controllerScope.restaurantObj["id"];
            restaurant["thumb"] = controllerScope.restaurantObj["thumb"];
            resDataObject.setRecord(restaurant);
            dataModel.create({
                dataObject: resDataObject
            }, function(successResponse) {
                kony.print("$$$$$$$$ creation success $$$$$$$" + JSON.stringify(successResponse));
                alert("restaurant added to your favourite list.");
                kony.model.ApplicationContext.dismissLoadingScreen();
            }, function(errorResponse) {
                kony.print("$$$$$$$$$$$$$$$ errorResponse $$$$$$$$ " + JSON.stringify(errorResponse.getRootErrorObj()));
                //alert("unable to add to ");
                kony.model.ApplicationContext.dismissLoadingScreen();
            });
        }

        function errorCB(err) {
            kony.print("$$$$$$$$$$$ err  $$$$$$$$$ " + JSON.stringify(err.getRootErrorObj()));
            kony.model.ApplicationContext.dismissLoadingScreen();
        }
        kony.model.ApplicationContext.showLoadingScreen("Please wait ..");
        kony.model.ApplicationContext.createModel("Restaurant", "FavouriteRestaurant", {
            "access": "online"
        }, {}, successCB, errorCB);
    },
    "locateRestaurant": function() {
        try {
            var navigateTofrmMap = new kony.mvc.Navigation("frmMap");
            navigateTofrmMap.navigate(this.restaurantObj);
        } catch (exp) {
            kony.print(JSON.stringify(exp));
        }
    },
    "navigateTofrmHome": function() {
        try {
            var navigateObj = new kony.mvc.Navigation("frmHome");
            navigateObj.navigate();
        } catch (exp) {
            kony.print(JSON.stringify(exp));
        }
    },
    "getFavouriteRestaurant": function() {
        var params = {};
        params.queryParams = {
            "$filter": "device_id eq " + "'" + kony.os.deviceInfo().deviceid + "'"
        };
        var navigateTofrmFavourite = new kony.mvc.Navigation("frmFavourite");
        var modelContext = new kony.model.ModelContext();
        modelContext.setRequestOptions("segRestaurant", params);
        navigateTofrmFavourite.setFormConfig(frmFavouriteConfig);
        navigateTofrmFavourite.setModelContext(modelContext);
        try {
            navigateTofrmFavourite.navigate();
        } catch (exp) {
            kony.print("Error in navigating the form");
        }
    },
    "AS_Button_35757ba08e0042db8e42402dc4f81253": function AS_Button_35757ba08e0042db8e42402dc4f81253(eventobject) {
        var self = this;
        this.getFavouriteRestaurant();
    },
    "AS_Button_ca05cd8f5cf545cfab4f3bc54b9ba5c4": function AS_Button_ca05cd8f5cf545cfab4f3bc54b9ba5c4(eventobject) {
        var self = this;
        this.navigateTofrmHome();
    },
    "AS_Button_gccb6d5ce90549eeb3831b46f0668c77": function AS_Button_gccb6d5ce90549eeb3831b46f0668c77(eventobject) {
        var self = this;
        this.showRestaurantMenu();
    },
    "AS_Image_f3e6d1ce516a4bc5908f5d3721573ea8": function AS_Image_f3e6d1ce516a4bc5908f5d3721573ea8(eventobject, x, y) {
        var self = this;
        this.makeRestaurantFavourite();
    },
    "AS_Button_g076c3717f304f15a92b480da27a7495": function AS_Button_g076c3717f304f15a92b480da27a7495(eventobject) {
        var self = this;
        this.locateRestaurant();
    },
    "AS_FlexContainer_c00e106eda614b09b4aebff533c06a9f": function AS_FlexContainer_c00e106eda614b09b4aebff533c06a9f(eventobject) {
        var self = this;
        this.showRestaurantMenu();
    }
})