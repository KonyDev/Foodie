define({
    "getCurrentLocation": function() {
        //        var controllerScope = this;
        kony.print("\n\n---in getCurrentLocation---\n\n");

        function geoSuccessCallBack(position) {
            var lat = position.coords.latitude;
            var lon = position.coords.longitude;
            kony.print("latitutde:-" + lat);
            kony.print("longitude:-" + lon);
            RESTAURANT_CONFIG.LATITUDE = lat;
            RESTAURANT_CONFIG.LONGITUDE = lon;
            kony.mvc.model.Utils.dismissLoadingScreen();
            this.getNearByRestaurant(lat, lon);
        }

        function geoErrorCallBack(positionerror) {
            kony.print("Error occured while retrieving the data:-\n" + "Error code:" + positionerror.code + " : " + positionerror.message);
            kony.print("error:-" + JSON.stringify(positionerror));
            alert(positionerror.message);
            if (positionerror.code == kony.location.PERMISSION_DENIED) {
                alert("PERMISSON IS DENIED");
            } else if (positionerror.code == kony.location.POSITION_UNAVAILABLE) {
                alert("POSITION_UNAVAILABLE");
            } else if (positionerror.code == kony.location.TIMEOUT) {
                alert("TIMEOUT in getting current location");
            }
            kony.mvc.model.Utils.dismissLoadingScreen();
        }
        var positionoptions = {
            timeout: 15000
        }; // 15 secs 
        kony.mvc.model.Utils.showLoadingScreen("Retrieving location...");
        try {
            kony.location.getCurrentPosition(geoSuccessCallBack.bind(this), geoErrorCallBack.bind(this), positionoptions);
        } catch (exception) {
            alert("Exception is ::" + exception.message);
        }
    },
    "getNearByRestaurant": function(lat, lon) {
        var params = {};
        params.headers = {
            "user-key": RESTAURANT_CONFIG.USER_KEY,
            "Accept": "application/json"
        };
        params.queryParams = {
            latitude: lat,
            longitude: lon
        };
        var navigateTofrmRestaurent = new kony.mvc.Navigation("frmRestaurants");
        var modelContext = new kony.mvc.model.ModelContext();
        modelContext.setRequestOptions("segRestaurant", params);
        navigateTofrmRestaurent.setFormConfig(frmRestaurantsConfig);
        navigateTofrmRestaurent.setModelContext(modelContext);
        try {
            navigateTofrmRestaurent.navigate();
        } catch (exp) {
            kony.print("Error in navigating the form");
        }
    },
    "AS_FlexContainer_8c56f6c502474badb5a9caf71c72e59c": function AS_FlexContainer_8c56f6c502474badb5a9caf71c72e59c(eventobject, x, y) {
        var self = this;
        this.getCurrentLocation();
    }
})