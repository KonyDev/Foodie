define("frmHome", function() {
    return function(controller) {
        function addWidgetsfrmHome() {
            this.setDefaultUnit(kony.flex.DP);
            var imgBg = new kony.ui.Image2({
                "centerX": "50%",
                "height": "100%",
                "id": "imgBg",
                "isVisible": true,
                "skin": "slImage",
                "src": "https://b.zmtcdn.com/images/foodshots/cover/pizza3.jpg",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_FIT_TO_DIMENSIONS,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var FlexRoot = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "centerY": "50%",
                "clipBounds": true,
                "height": "100%",
                "id": "FlexRoot",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "skin": "slFbox",
                "width": "100%",
                "zIndex": 2
            }, {}, {});
            FlexRoot.setDefaultUnit(kony.flex.DP);
            var imgLogo = new kony.ui.Image2({
                "centerX": "50%",
                "id": "imgLogo",
                "isVisible": true,
                "skin": "slImage",
                "src": "logo.png",
                "top": "20dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxOptions = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "40dp",
                "centerX": "50%",
                "clipBounds": true,
                "height": "300dp",
                "id": "flxOptions",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "skin": "sknFlxPinkTrans",
                "width": "95%",
                "zIndex": 1
            }, {}, {});
            flxOptions.setDefaultUnit(kony.flex.DP);
            var FlexContainer0da625068f57d41 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "25%",
                "centerY": "25%",
                "clipBounds": true,
                "height": "115dp",
                "id": "FlexContainer0da625068f57d41",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "81dp",
                "onTouchEnd": controller.AS_FlexContainer_8c56f6c502474badb5a9caf71c72e59c,
                "skin": "sknFlxWhite",
                "top": "34dp",
                "width": "115dp",
                "zIndex": 1
            }, {}, {});
            FlexContainer0da625068f57d41.setDefaultUnit(kony.flex.DP);
            var Image04bcfc3ee865e45 = new kony.ui.Image2({
                "centerX": "50%",
                "centerY": "45%",
                "height": "100%",
                "id": "Image04bcfc3ee865e45",
                "isVisible": true,
                "skin": "slImage",
                "src": "nearme.png",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblNearByRes = new kony.ui.Label({
                "bottom": "0dp",
                "centerX": "50%",
                "id": "lblNearByRes",
                "isVisible": true,
                "skin": "sknLblBlue",
                "text": "Near Me",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "textCopyable": false,
                "wrapping": constants.WIDGET_TEXT_WORD_WRAP
            });
            FlexContainer0da625068f57d41.add(Image04bcfc3ee865e45, lblNearByRes);
            flxOptions.add(FlexContainer0da625068f57d41);
            var lblTitle = new kony.ui.Label({
                "centerX": "50%",
                "centerY": "90dp",
                "id": "lblTitle",
                "isVisible": true,
                "skin": "sknLblTitle",
                "text": "Foodie",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "textCopyable": false,
                "wrapping": constants.WIDGET_TEXT_WORD_WRAP
            });
            FlexRoot.add(imgLogo, flxOptions, lblTitle);
            this.add(imgBg, FlexRoot);
        };
        return [{
            "addWidgets": addWidgetsfrmHome,
            "enabledForIdleTimeout": false,
            "id": "frmHome",
            "layoutType": kony.flex.FREE_FORM,
            "needAppMenu": false,
            "skin": "slForm",
            "title": "Home",
            "info": {
                "kuid": "2dfdf38e41174418a107adc63ba4aaaa"
            }
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": kony.flex.FREE_FORM,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {
            "configureExtendBottom": false,
            "configureExtendTop": false,
            "configureStatusBarStyle": false,
            "footerOverlap": false,
            "formTransparencyDuringPostShow": "100",
            "headerOverlap": false,
            "inputAccessoryViewType": constants.FORM_INPUTACCESSORYVIEW_CANCEL,
            "needsIndicatorDuringPostShow": false,
            "retainScrollPosition": false,
            "titleBar": true,
            "titleBarConfig": {
                "renderTitleText": true,
                "prevFormTitle": false,
                "titleBarLeftSideView": "button",
                "labelLeftSideView": "Back",
                "titleBarRightSideView": "button",
                "labelRightSideView": "Edit"
            },
            "titleBarSkin": "sknLblFrmTitle"
        }]
    }
});